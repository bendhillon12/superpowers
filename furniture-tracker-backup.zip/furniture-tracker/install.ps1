# Furniture Tracker - Automated Installation Script (Windows)
# This script automates the installation process for the furniture tracking application

$ErrorActionPreference = "Stop"

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Furniture Tracker - Installation Wizard" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Function to print colored messages
function Print-Success {
    param($Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

function Print-Error {
    param($Message)
    Write-Host "✗ $Message" -ForegroundColor Red
}

function Print-Warning {
    param($Message)
    Write-Host "⚠ $Message" -ForegroundColor Yellow
}

function Print-Step {
    param($Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Green
}

function Command-Exists {
    param($Command)
    $null -ne (Get-Command $Command -ErrorAction SilentlyContinue)
}

# Step 1: Check prerequisites
Print-Step "Checking prerequisites..."

if (-not (Command-Exists "node")) {
    Print-Error "Node.js is not installed. Please install Node.js 18 or higher."
    Write-Host "Download from: https://nodejs.org/"
    exit 1
}

$nodeVersion = (node -v).TrimStart('v').Split('.')[0]
if ([int]$nodeVersion -lt 18) {
    Print-Error "Node.js version 18 or higher is required. Current version: $(node -v)"
    exit 1
}
Print-Success "Node.js $(node -v) found"

if (-not (Command-Exists "npm")) {
    Print-Error "npm is not installed."
    exit 1
}
Print-Success "npm $(npm -v) found"

if (-not (Command-Exists "psql")) {
    Print-Warning "PostgreSQL client (psql) not found."
    Write-Host "PostgreSQL is required. Please install PostgreSQL 15+ first."
    Write-Host "Download from: https://www.postgresql.org/download/windows/"
    $response = Read-Host "Continue anyway? (y/n)"
    if ($response -notmatch '^[Yy]$') {
        exit 1
    }
} else {
    Print-Success "PostgreSQL found"
}

# Step 2: Install npm dependencies
Print-Step "Installing npm dependencies..."
npm install
Print-Success "Dependencies installed"

# Step 3: Setup environment file
Print-Step "Setting up environment configuration..."

if (Test-Path ".env") {
    Print-Warning ".env file already exists"
    $response = Read-Host "Do you want to reconfigure? (y/n)"
    if ($response -notmatch '^[Yy]$') {
        Print-Success "Using existing .env file"
        $skipEnv = $true
    } else {
        Remove-Item ".env"
        $skipEnv = $false
    }
} else {
    $skipEnv = $false
}

if (-not $skipEnv) {
    Write-Host ""
    Write-Host "Let's configure your database connection..."
    Write-Host ""

    # Database configuration
    $dbHost = Read-Host "Database host (default: localhost)"
    if ([string]::IsNullOrWhiteSpace($dbHost)) { $dbHost = "localhost" }

    $dbPort = Read-Host "Database port (default: 5432)"
    if ([string]::IsNullOrWhiteSpace($dbPort)) { $dbPort = "5432" }

    $dbName = Read-Host "Database name (default: furniture_tracker)"
    if ([string]::IsNullOrWhiteSpace($dbName)) { $dbName = "furniture_tracker" }

    $dbUser = Read-Host "Database username (default: postgres)"
    if ([string]::IsNullOrWhiteSpace($dbUser)) { $dbUser = "postgres" }

    $dbPasswordSecure = Read-Host "Database password" -AsSecureString
    $dbPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [Runtime.InteropServices.Marshal]::SecureStringToBSTR($dbPasswordSecure)
    )

    # Create database if it doesn't exist (try)
    Write-Host ""
    Write-Host "Attempting to create database..."
    $env:PGPASSWORD = $dbPassword
    try {
        & createdb -h $dbHost -p $dbPort -U $dbUser $dbName 2>$null
        Print-Success "Database created"
    } catch {
        Print-Warning "Database may already exist (continuing...)"
    }
    Remove-Item Env:\PGPASSWORD

    # Create .env file
    $envContent = @"
# Database
DATABASE_URL="postgresql://${dbUser}:${dbPassword}@${dbHost}:${dbPort}/${dbName}?schema=public"

# Application
NODE_ENV=production
PORT=3000

# Optional: Email configuration (can be configured later)
# EMAIL_HOST=smtp.gmail.com
# EMAIL_PORT=587
# EMAIL_USER=your-email@gmail.com
# EMAIL_PASSWORD=your-app-password

# Optional: OneDrive configuration (can be configured later)
# ONEDRIVE_CLIENT_ID=
# ONEDRIVE_CLIENT_SECRET=
# ONEDRIVE_REFRESH_TOKEN=
"@

    Set-Content -Path ".env" -Value $envContent
    Print-Success ".env file created"
}

# Step 4: Generate Prisma Client
Print-Step "Generating Prisma client..."
npx prisma generate
Print-Success "Prisma client generated"

# Step 5: Run database migrations
Print-Step "Running database migrations..."
npx prisma migrate deploy
Print-Success "Database migrations completed"

# Step 6: Seed initial data
Print-Step "Seeding initial data..."
Write-Host ""
Write-Host "This will create 3 sample stations and 3 sample materials."
Write-Host "You can modify or delete these later in the admin dashboard."
Write-Host ""
$seedResponse = Read-Host "Seed database with sample data? (y/n)"

if ($seedResponse -match '^[Yy]$') {
    node scripts/seed-stations.js
    Print-Success "Database seeded"
} else {
    Print-Warning "Skipping database seeding"
}

# Step 7: Build the application
Print-Step "Building the application..."
npm run build
Print-Success "Application built successfully"

# Step 8: Get local IP address
Print-Step "Network configuration..."
Write-Host ""
Write-Host "Finding your local IP address..."

try {
    $localIP = (Get-NetIPAddress -AddressFamily IPv4 |
                Where-Object { $_.IPAddress -notlike "127.*" -and $_.PrefixOrigin -eq "Dhcp" } |
                Select-Object -First 1).IPAddress

    if ($localIP) {
        Print-Success "Local IP address: $localIP"
    } else {
        Print-Warning "Could not detect IP address automatically"
        $localIP = "your-ip-address"
    }
} catch {
    Print-Warning "Could not detect IP address automatically"
    $localIP = "your-ip-address"
}

# Step 9: Create Windows service option
Print-Step "Windows Service Setup (Optional)..."
Write-Host ""
Write-Host "Would you like to install as a Windows service?"
Write-Host "This will make the application start automatically with Windows."
$serviceResponse = Read-Host "(y/n)"

if ($serviceResponse -match '^[Yy]$') {
    if (-not (Command-Exists "node-windows")) {
        Write-Host "Installing node-windows for service management..."
        npm install -g node-windows
    }

    # Create service install script
    $serviceScript = @"
var Service = require('node-windows').Service;

var svc = new Service({
  name: 'Furniture Tracker',
  description: 'Furniture Manufacturing WIP Tracker',
  script: require('path').join(__dirname, 'node_modules', 'next', 'dist', 'bin', 'next'),
  scriptOptions: 'start',
  nodeOptions: [],
  env: [{
    name: "NODE_ENV",
    value: "production"
  }]
});

svc.on('install', function(){
  console.log('Service installed successfully!');
  svc.start();
});

svc.on('alreadyinstalled', function(){
  console.log('Service is already installed.');
});

svc.install();
"@

    Set-Content -Path "install-service.js" -Value $serviceScript

    Write-Host "Installing as Windows service..."
    Write-Host "Note: This may require administrator privileges"
    node install-service.js

    Print-Success "Service installed (check Windows Services)"
}

# Step 10: Installation complete
Print-Step "Installation complete!"
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  🎉 Installation Successful!" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Start the application:" -ForegroundColor White
Write-Host "   npm start" -ForegroundColor Cyan
Write-Host ""
Write-Host "2. Access the application:" -ForegroundColor White
Write-Host "   - Worker interface: http://localhost:3000/station" -ForegroundColor Cyan
Write-Host "   - Admin dashboard:  http://localhost:3000/admin" -ForegroundColor Cyan
Write-Host ""

if ($localIP -ne "your-ip-address") {
    Write-Host "3. Workers can access from tablets/phones on the same network:" -ForegroundColor White
    Write-Host "   - Worker interface: http://${localIP}:3000/station" -ForegroundColor Cyan
    Write-Host "   - Admin dashboard:  http://${localIP}:3000/admin" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host "4. Configure barcode scanning:" -ForegroundColor White
Write-Host "   - Print station barcodes (Code 128 format)" -ForegroundColor Gray
Write-Host "   - Station IDs are in the database" -ForegroundColor Gray
Write-Host "   - Order barcodes are auto-generated" -ForegroundColor Gray
Write-Host ""
Write-Host "5. Optional configuration (edit .env):" -ForegroundColor White
Write-Host "   - Email notifications (Gmail app password)" -ForegroundColor Gray
Write-Host "   - OneDrive integration" -ForegroundColor Gray
Write-Host ""
Write-Host "For more details, see DEPLOYMENT.md" -ForegroundColor Yellow
Write-Host ""

# Ask if user wants to start the app now
$startNow = Read-Host "Start the application now? (y/n)"

if ($startNow -match '^[Yy]$') {
    Write-Host ""
    Print-Step "Starting application..."
    Write-Host ""
    Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
    Write-Host ""
    npm start
} else {
    Write-Host ""
    Write-Host "To start later, run: npm start" -ForegroundColor Cyan
    Write-Host ""
}
