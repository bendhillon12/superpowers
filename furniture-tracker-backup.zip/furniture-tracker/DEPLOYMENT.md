# Deployment Guide

## Prerequisites

- Node.js 18+ installed
- PostgreSQL 15+ installed and running
- Local network access

## Installation Steps

### 1. Clone and Install

```bash
git clone <repository-url>
cd furniture-tracker
npm install
```

### 2. Database Setup

```bash
# Create PostgreSQL database
createdb furniture_tracker

# Copy environment template
cp .env.example .env
```

Edit `.env`:

```
DATABASE_URL="postgresql://username:password@localhost:5432/furniture_tracker"
ADMIN_PASSWORD_HASH="<generate-hash>"
SESSION_SECRET="<random-string>"
```

Generate admin password hash:

```bash
node -e "console.log(require('bcrypt').hashSync('your-password', 10))"
```

### 3. Run Migrations

```bash
npx prisma migrate deploy
npx prisma generate
```

### 4. Seed Initial Data

Create 3 stations:

```bash
node scripts/seed-stations.js
```

### 5. Build and Start

```bash
npm run build
npm start
```

Application runs on port 3000.

### 6. Access on Local Network

Find server IP:

```bash
ifconfig | grep inet
```

Workers access: `http://192.168.x.x:3000/station`
Admin access: `http://192.168.x.x:3000/admin`

## Barcode Setup

1. Generate station barcodes (Code 128 format)
2. Print and laminate
3. Post at each workstation

Order barcodes are auto-generated when orders are created.

## Email Configuration

For Gmail:
1. Enable 2-factor authentication
2. Create app password
3. Add to .env:

```
EMAIL_HOST="smtp.gmail.com"
EMAIL_PORT="587"
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="app-password"
```

## OneDrive Configuration

1. Register app at https://portal.azure.com
2. Get client ID and secret
3. Generate refresh token
4. Add to .env

## Backups

Automated daily backups:

```bash
# Add to crontab
0 2 * * * pg_dump furniture_tracker > /backups/furniture_tracker_$(date +\%Y\%m\%d).sql
```

## Troubleshooting

### Database connection fails
- Check PostgreSQL is running: `sudo service postgresql status`
- Verify DATABASE_URL in .env

### Barcode scanning doesn't work
- Grant camera permissions in browser
- Use manual entry as fallback
- Verify QuaggaJS loaded correctly

### Can't access from other devices
- Check firewall allows port 3000
- Verify devices on same network
- Use server's local IP address
