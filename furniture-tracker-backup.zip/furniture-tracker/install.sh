#!/bin/bash

# Furniture Tracker - Automated Installation Script
# This script automates the installation process for the furniture tracking application

set -e  # Exit on any error

echo "================================================"
echo "  Furniture Tracker - Installation Wizard"
echo "================================================"
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_step() {
    echo -e "\n${GREEN}==>${NC} $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Step 1: Check prerequisites
print_step "Checking prerequisites..."

if ! command_exists node; then
    print_error "Node.js is not installed. Please install Node.js 18 or higher."
    echo "Download from: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1)
if [ "$NODE_VERSION" -lt 18 ]; then
    print_error "Node.js version 18 or higher is required. Current version: $(node -v)"
    exit 1
fi
print_success "Node.js $(node -v) found"

if ! command_exists npm; then
    print_error "npm is not installed."
    exit 1
fi
print_success "npm $(npm -v) found"

if ! command_exists psql; then
    print_warning "PostgreSQL client (psql) not found."
    echo "PostgreSQL is required. Please install PostgreSQL 15+ first."
    echo "Continue anyway? (y/n)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    print_success "PostgreSQL found"
fi

# Step 2: Install npm dependencies
print_step "Installing npm dependencies..."
npm install
print_success "Dependencies installed"

# Step 3: Setup environment file
print_step "Setting up environment configuration..."

if [ -f ".env" ]; then
    print_warning ".env file already exists"
    echo "Do you want to reconfigure? (y/n)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        print_success "Using existing .env file"
    else
        rm .env
    fi
fi

if [ ! -f ".env" ]; then
    echo ""
    echo "Let's configure your database connection..."
    echo ""

    # Database configuration
    read -p "Database host (default: localhost): " DB_HOST
    DB_HOST=${DB_HOST:-localhost}

    read -p "Database port (default: 5432): " DB_PORT
    DB_PORT=${DB_PORT:-5432}

    read -p "Database name (default: furniture_tracker): " DB_NAME
    DB_NAME=${DB_NAME:-furniture_tracker}

    read -p "Database username (default: postgres): " DB_USER
    DB_USER=${DB_USER:-postgres}

    read -sp "Database password: " DB_PASSWORD
    echo ""

    # Create database if it doesn't exist (try)
    echo ""
    echo "Attempting to create database..."
    PGPASSWORD="$DB_PASSWORD" createdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME" 2>/dev/null && print_success "Database created" || print_warning "Database may already exist (continuing...)"

    # Create .env file
    cat > .env << EOF
# Database
DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?schema=public"

# Application
NODE_ENV=production
PORT=3000

# Optional: Email configuration (can be configured later)
# EMAIL_HOST=smtp.gmail.com
# EMAIL_PORT=587
# EMAIL_USER=your-email@gmail.com
# EMAIL_PASSWORD=your-app-password

# Optional: OneDrive configuration (can be configured later)
# ONEDRIVE_CLIENT_ID=
# ONEDRIVE_CLIENT_SECRET=
# ONEDRIVE_REFRESH_TOKEN=
EOF

    print_success ".env file created"
fi

# Step 4: Generate Prisma Client
print_step "Generating Prisma client..."
npx prisma generate
print_success "Prisma client generated"

# Step 5: Run database migrations
print_step "Running database migrations..."
npx prisma migrate deploy
print_success "Database migrations completed"

# Step 6: Seed initial data
print_step "Seeding initial data..."
echo ""
echo "This will create 3 sample stations and 3 sample materials."
echo "You can modify or delete these later in the admin dashboard."
echo ""
read -p "Seed database with sample data? (y/n): " SEED_RESPONSE

if [[ "$SEED_RESPONSE" =~ ^[Yy]$ ]]; then
    node scripts/seed-stations.js
    print_success "Database seeded"
else
    print_warning "Skipping database seeding"
fi

# Step 7: Build the application
print_step "Building the application..."
npm run build
print_success "Application built successfully"

# Step 8: Get local IP address
print_step "Network configuration..."
echo ""
echo "Finding your local IP address..."

if command_exists ip; then
    LOCAL_IP=$(ip route get 1 | awk '{print $7;exit}')
elif command_exists ifconfig; then
    LOCAL_IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -1)
else
    LOCAL_IP="your-ip-address"
fi

if [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "your-ip-address" ]; then
    print_success "Local IP address: $LOCAL_IP"
else
    print_warning "Could not detect IP address automatically"
    LOCAL_IP="your-ip-address"
fi

# Step 9: Installation complete
print_step "Installation complete!"
echo ""
echo "================================================"
echo "  🎉 Installation Successful!"
echo "================================================"
echo ""
echo "Next steps:"
echo ""
echo "1. Start the application:"
echo "   npm start"
echo ""
echo "2. Access the application:"
echo "   - Worker interface: http://localhost:3000/station"
echo "   - Admin dashboard:  http://localhost:3000/admin"
echo ""
if [ "$LOCAL_IP" != "your-ip-address" ]; then
    echo "3. Workers can access from tablets/phones on the same network:"
    echo "   - Worker interface: http://${LOCAL_IP}:3000/station"
    echo "   - Admin dashboard:  http://${LOCAL_IP}:3000/admin"
    echo ""
fi
echo "4. Configure barcode scanning:"
echo "   - Print station barcodes (Code 128 format)"
echo "   - Station IDs are in the database"
echo "   - Order barcodes are auto-generated"
echo ""
echo "5. Optional configuration (edit .env):"
echo "   - Email notifications (Gmail app password)"
echo "   - OneDrive integration"
echo ""
echo "For more details, see DEPLOYMENT.md"
echo ""

# Ask if user wants to start the app now
read -p "Start the application now? (y/n): " START_NOW

if [[ "$START_NOW" =~ ^[Yy]$ ]]; then
    echo ""
    print_step "Starting application..."
    echo ""
    echo "Press Ctrl+C to stop the server"
    echo ""
    npm start
else
    echo ""
    echo "To start later, run: npm start"
    echo ""
fi
