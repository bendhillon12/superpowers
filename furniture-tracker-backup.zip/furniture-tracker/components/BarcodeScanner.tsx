'use client'

import { useEffect, useRef, useState } from 'react'
import Quagga from 'quagga'

interface BarcodeScannerProps {
  onScan: (barcode: string) => void
  active: boolean
}

export default function BarcodeScanner({ onScan, active }: BarcodeScannerProps) {
  const scannerRef = useRef<HTMLDivElement>(null)
  const [manualEntry, setManualEntry] = useState(false)
  const [manualCode, setManualCode] = useState('')
  const [cameraError, setCameraError] = useState(false)

  useEffect(() => {
    if (!active || manualEntry) return

    if (scannerRef.current) {
      Quagga.init({
        inputStream: {
          type: 'LiveStream',
          target: scannerRef.current,
          constraints: {
            facingMode: 'environment'
          }
        },
        decoder: {
          readers: ['code_128_reader', 'ean_reader', 'ean_8_reader', 'upc_reader']
        }
      }, (err) => {
        if (err) {
          console.error('Barcode scanner init error:', err)
          setCameraError(true)
          setManualEntry(true)
          return
        }
        Quagga.start()
      })

      Quagga.onDetected((result) => {
        if (result.codeResult.code) {
          onScan(result.codeResult.code)
          Quagga.stop()
        }
      })
    }

    return () => {
      Quagga.stop()
    }
  }, [active, manualEntry, onScan])

  if (manualEntry) {
    return (
      <div className="p-4 space-y-4">
        {cameraError && (
          <div className="p-4 bg-yellow-100 border-2 border-yellow-400 rounded">
            <p className="text-xl text-yellow-800">
              Camera not available. Please enter barcode manually.
            </p>
          </div>
        )}
        <input
          type="text"
          value={manualCode}
          onChange={(e) => setManualCode(e.target.value)}
          placeholder="Enter barcode manually"
          className="w-full p-6 text-3xl border-4 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
          autoFocus
        />
        <button
          onClick={() => {
            if (manualCode.trim()) {
              onScan(manualCode.trim())
              setManualCode('')
            }
          }}
          className="w-full p-6 text-3xl font-bold bg-blue-600 text-white rounded-lg hover:bg-blue-700 active:bg-blue-800"
        >
          Submit
        </button>
        {!cameraError && (
          <button
            onClick={() => {
              setManualEntry(false)
              setCameraError(false)
            }}
            className="w-full p-4 text-xl bg-gray-300 rounded-lg hover:bg-gray-400"
          >
            Try Camera Again
          </button>
        )}
      </div>
    )
  }

  return (
    <div className="relative">
      <div ref={scannerRef} className="w-full h-80 bg-black rounded-lg overflow-hidden" />
      <div className="mt-4 p-4 bg-blue-100 border-2 border-blue-300 rounded-lg">
        <p className="text-xl text-center text-blue-800">
          Point camera at barcode
        </p>
      </div>
      <button
        onClick={() => setManualEntry(true)}
        className="mt-4 w-full p-4 text-xl bg-gray-300 rounded-lg hover:bg-gray-400"
      >
        Enter Manually Instead
      </button>
    </div>
  )
}
