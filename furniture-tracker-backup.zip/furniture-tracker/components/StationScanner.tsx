'use client'

import { useState, useEffect } from 'react'
import BarcodeScanner from './BarcodeScanner'

interface Station {
  id: string
  name: string
  description?: string
}

interface Order {
  id: string
  orderNumber: string
  customerName: string
  status: string
}

export default function StationScanner() {
  const [stations, setStations] = useState<Station[]>([])
  const [currentStation, setCurrentStation] = useState<Station | null>(null)
  const [ordersAtStation, setOrdersAtStation] = useState<Order[]>([])
  const [scanning, setScanning] = useState(false)
  const [message, setMessage] = useState<string>('')
  const [messageType, setMessageType] = useState<'success' | 'error'>('success')
  const [loading, setLoading] = useState(true)

  // Load all stations on mount
  useEffect(() => {
    loadStations()
  }, [])

  const loadStations = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/stations')
      if (response.ok) {
        const data = await response.json()
        setStations(data)
      } else {
        showMessage('Failed to load stations', 'error')
      }
    } catch (error) {
      console.error('Failed to load stations:', error)
      showMessage('Failed to load stations', 'error')
    } finally {
      setLoading(false)
    }
  }

  const fetchOrdersAtStation = async (stationId: string) => {
    try {
      const response = await fetch(`/api/stations/${stationId}/orders`)
      if (response.ok) {
        const orders = await response.json()
        setOrdersAtStation(orders)
      } else {
        console.error('Failed to fetch orders')
        setOrdersAtStation([])
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error)
      setOrdersAtStation([])
    }
  }

  const handleStationSelect = async (station: Station) => {
    setCurrentStation(station)
    await fetchOrdersAtStation(station.id)
    showMessage(`Station: ${station.name}`, 'success')
  }

  const handleOrderScan = async (barcode: string) => {
    if (!currentStation) {
      showMessage('Please select a station first', 'error')
      return
    }

    try {
      // The barcode is treated as the order ID directly
      const orderId = barcode

      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          stationId: currentStation.id
        })
      })

      const result = await response.json()

      if (response.ok) {
        showMessage(result.message, 'success')
        // Refresh the orders list
        await fetchOrdersAtStation(currentStation.id)
        // Reset scanner for next scan
        setScanning(false)
        setTimeout(() => setScanning(true), 500)
      } else {
        showMessage(result.error || 'Scan failed', 'error')
        setScanning(false)
        setTimeout(() => setScanning(true), 2000)
      }
    } catch (error) {
      console.error('Scan error:', error)
      showMessage('Failed to process scan', 'error')
      setScanning(false)
      setTimeout(() => setScanning(true), 2000)
    }
  }

  const showMessage = (msg: string, type: 'success' | 'error') => {
    setMessage(msg)
    setMessageType(type)
    setTimeout(() => setMessage(''), 4000)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 p-4 flex items-center justify-center">
        <div className="text-3xl font-bold text-gray-600">Loading stations...</div>
      </div>
    )
  }

  // Station selection screen
  if (!currentStation) {
    return (
      <div className="min-h-screen bg-gray-100 p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 mb-4">
          <h1 className="text-5xl font-bold text-center mb-2">Select Your Station</h1>
          <p className="text-2xl text-center text-gray-600">Tap the station where you are working</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {stations.length === 0 ? (
            <div className="col-span-full bg-white rounded-lg shadow p-8">
              <p className="text-2xl text-center text-gray-500">No stations available</p>
            </div>
          ) : (
            stations.map(station => (
              <button
                key={station.id}
                onClick={() => handleStationSelect(station)}
                className="bg-white rounded-lg shadow-lg p-8 hover:bg-blue-50 active:bg-blue-100 border-4 border-transparent hover:border-blue-300 transition-all"
              >
                <h2 className="text-4xl font-bold text-blue-900 mb-2">{station.name}</h2>
                {station.description && (
                  <p className="text-xl text-gray-600">{station.description}</p>
                )}
              </button>
            ))
          )}
        </div>

        {message && (
          <div className={`fixed top-0 left-0 right-0 p-8 text-center text-white text-3xl font-bold ${
            messageType === 'success' ? 'bg-green-600' : 'bg-red-600'
          }`}>
            {messageType === 'success' ? '✓' : '✗'} {message}
          </div>
        )}
      </div>
    )
  }

  // Scanning screen (after station selected)
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-5xl font-bold text-blue-900">{currentStation.name}</h1>
            {currentStation.description && (
              <p className="text-xl text-gray-600 mt-2">{currentStation.description}</p>
            )}
          </div>
          <button
            onClick={() => {
              setCurrentStation(null)
              setOrdersAtStation([])
              setScanning(false)
            }}
            className="px-8 py-4 text-2xl font-bold bg-gray-300 rounded-lg hover:bg-gray-400 active:bg-gray-500"
          >
            Change Station
          </button>
        </div>
      </div>

      {/* Orders at station */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
        <h2 className="text-3xl font-bold mb-4 text-gray-800">Orders at this station:</h2>
        {ordersAtStation.length === 0 ? (
          <p className="text-gray-500 text-2xl">No orders currently at this station</p>
        ) : (
          <ul className="space-y-3">
            {ordersAtStation.map(order => (
              <li key={order.id} className="text-2xl p-4 bg-gray-50 rounded-lg border-2 border-gray-200">
                <span className="font-bold text-blue-900">Order {order.orderNumber}</span>
                <span className="text-gray-600 ml-4">- {order.customerName}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Scanner */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
        <h2 className="text-3xl font-bold mb-6 text-center text-gray-800">
          SCAN ORDER BARCODE
        </h2>
        {!scanning ? (
          <button
            onClick={() => setScanning(true)}
            className="w-full p-8 text-3xl font-bold bg-green-600 text-white rounded-lg hover:bg-green-700 active:bg-green-800"
          >
            Start Scanning
          </button>
        ) : (
          <>
            <BarcodeScanner
              onScan={handleOrderScan}
              active={scanning}
            />
            <button
              onClick={() => setScanning(false)}
              className="w-full mt-4 p-4 text-xl bg-red-500 text-white rounded-lg hover:bg-red-600"
            >
              Stop Scanning
            </button>
          </>
        )}
      </div>

      {/* Message notification */}
      {message && (
        <div className={`fixed top-0 left-0 right-0 p-8 text-center text-white text-4xl font-bold shadow-lg ${
          messageType === 'success' ? 'bg-green-600' : 'bg-red-600'
        }`}>
          <div className="container mx-auto">
            {messageType === 'success' ? '✓' : '✗'} {message}
          </div>
        </div>
      )}
    </div>
  )
}
