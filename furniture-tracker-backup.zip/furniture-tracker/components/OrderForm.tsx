'use client'

import { useState } from 'react'

interface OrderMaterial {
  materialId: string
  plannedQuantity: number
}

interface OrderFormData {
  customerName: string
  orderNumber: string
  materials: OrderMaterial[]
}

interface OrderFormProps {
  onSubmit: (order: OrderFormData) => void
  onCancel: () => void
}

export default function OrderForm({ onSubmit, onCancel }: OrderFormProps) {
  const [customerName, setCustomerName] = useState('')
  const [orderNumber, setOrderNumber] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      customerName,
      orderNumber,
      materials: []
    })
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6 space-y-4">
      <h2 className="text-2xl font-bold">Create New Order</h2>

      <div>
        <label htmlFor="orderNumber" className="block text-sm font-medium mb-1">
          Order Number
        </label>
        <input
          id="orderNumber"
          type="text"
          value={orderNumber}
          onChange={(e) => setOrderNumber(e.target.value)}
          className="w-full border rounded p-2"
          placeholder="Auto-generated if empty"
        />
      </div>

      <div>
        <label htmlFor="customerName" className="block text-sm font-medium mb-1">
          Customer Name <span className="text-red-500">*</span>
        </label>
        <input
          id="customerName"
          type="text"
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
          className="w-full border rounded p-2"
          required
        />
      </div>

      <div className="flex gap-2">
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
          disabled={!customerName.trim()}
        >
          Create Order
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
        >
          Cancel
        </button>
      </div>
    </form>
  )
}
