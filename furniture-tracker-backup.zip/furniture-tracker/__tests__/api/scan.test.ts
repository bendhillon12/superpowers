/**
 * @jest-environment node
 */
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals'
import { prisma } from '../../lib/prisma'
import { POST } from '@/app/api/scan/route'

describe('POST /api/scan', () => {
  let orderId: string
  let stationId1: string
  let stationId2: string

  beforeAll(async () => {
    // Create test stations
    const station1 = await prisma.station.create({
      data: { name: 'Test Station 1', laborRate: 25 }
    })
    stationId1 = station1.id

    const station2 = await prisma.station.create({
      data: { name: 'Test Station 2', laborRate: 30 }
    })
    stationId2 = station2.id

    // Create test order
    const order = await prisma.order.create({
      data: { orderNumber: 'TEST-SCAN-001', customerName: 'Test Scanner' }
    })
    orderId = order.id
  })

  afterAll(async () => {
    // Clean up test data
    await prisma.stationLog.deleteMany({
      where: { orderId }
    })
    await prisma.order.delete({
      where: { id: orderId }
    })
    await prisma.station.deleteMany({
      where: {
        id: { in: [stationId1, stationId2] }
      }
    })
  })

  describe('CHECK_IN: Order not at any station', () => {
    it('checks in an order to a station', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId,
          stationId: stationId1
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.action).toBe('CHECK_IN')
      expect(data.log).toBeDefined()
      expect(data.log.orderId).toBe(orderId)
      expect(data.log.stationId).toBe(stationId1)
      expect(data.log.checkOutAt).toBeNull()
      expect(data.message).toContain('checked in')

      // Verify order status updated to "In Progress"
      const order = await prisma.order.findUnique({
        where: { id: orderId }
      })
      expect(order?.status).toBe('In Progress')
    })
  })

  describe('CHECK_OUT: Order at same station', () => {
    it('checks out an order from a station', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId,
          stationId: stationId1
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.action).toBe('CHECK_OUT')
      expect(data.log).toBeDefined()
      expect(data.log.checkOutAt).not.toBeNull()
      expect(data.message).toContain('checked out')
    })
  })

  describe('TRANSFER: Order at different station', () => {
    it('auto checks out from old station and checks in to new station', async () => {
      // First, check in to station 1
      await POST(new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({ orderId, stationId: stationId1 })
      }))

      // Then scan at station 2 (should trigger transfer)
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId,
          stationId: stationId2
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.action).toBe('TRANSFER')
      expect(data.log).toBeDefined()
      expect(data.log.stationId).toBe(stationId2)
      expect(data.log.checkOutAt).toBeNull()
      expect(data.message).toContain('moved from')

      // Verify old station was checked out
      const oldLog = await prisma.stationLog.findFirst({
        where: {
          orderId,
          stationId: stationId1,
          checkOutAt: { not: null }
        },
        orderBy: { checkInAt: 'desc' }
      })
      expect(oldLog).toBeDefined()
      expect(oldLog?.checkOutAt).not.toBeNull()
    })
  })

  describe('Validation', () => {
    it('rejects missing orderId', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          stationId: stationId1
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })

    it('rejects missing stationId', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })

    it('rejects empty orderId', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId: '',
          stationId: stationId1
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })

    it('rejects empty stationId', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId,
          stationId: ''
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })
  })

  describe('Error handling', () => {
    it('handles non-existent order gracefully', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId: 'non-existent-id',
          stationId: stationId1
        })
      })

      const response = await POST(request)
      expect(response.status).toBeGreaterThanOrEqual(400)
    })

    it('handles non-existent station gracefully', async () => {
      const request = new Request('http://localhost:3000/api/scan', {
        method: 'POST',
        body: JSON.stringify({
          orderId,
          stationId: 'non-existent-station'
        })
      })

      const response = await POST(request)
      expect(response.status).toBeGreaterThanOrEqual(400)
    })
  })
})
