/**
 * @jest-environment node
 */
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals'
import { prisma } from '../../lib/prisma'
import { GET } from '@/app/api/stations/route'

describe('GET /api/stations', () => {
  let testStationId: string

  beforeAll(async () => {
    const station = await prisma.station.create({
      data: {
        name: 'Test Station',
        description: 'Test',
        laborRate: 25,
        sortOrder: 1
      }
    })
    testStationId = station.id
  })

  afterAll(async () => {
    await prisma.station.delete({ where: { id: testStationId } })
  })

  it('returns all active stations', async () => {
    const request = new Request('http://localhost:3000/api/stations')
    const response = await GET()
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(Array.isArray(data)).toBe(true)
    expect(data.length).toBeGreaterThan(0)
  })
})
