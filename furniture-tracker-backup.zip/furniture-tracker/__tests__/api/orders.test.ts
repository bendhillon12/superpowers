/**
 * @jest-environment node
 */
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals'
import { prisma } from '../../lib/prisma'
import { GET, POST } from '@/app/api/orders/route'
import { GET as getById, PUT, DELETE } from '@/app/api/orders/[id]/route'
import { GET as getCosts } from '@/app/api/orders/[id]/costs/route'

describe('Orders API', () => {
  let testOrderId: string
  let testMaterialId: string
  let testStyleId: string

  beforeAll(async () => {
    // Create test material
    const material = await prisma.material.create({
      data: {
        name: 'Test Order Material',
        type: 'leather',
        unitOfMeasure: 'sheets',
        currentQuantity: 100,
        unitCost: 50.0,
      }
    })
    testMaterialId = material.id

    // Create test style template
    const style = await prisma.materialTemplate.create({
      data: {
        name: 'Test Order Style',
        description: 'A test style template'
      }
    })
    testStyleId = style.id

    // Create test order
    const order = await prisma.order.create({
      data: {
        orderNumber: 'TEST-ORD-001',
        customerName: 'Test Customer',
        styleId: testStyleId,
      }
    })
    testOrderId = order.id
  })

  afterAll(async () => {
    // Clean up test data
    await prisma.orderMaterial.deleteMany({
      where: { orderId: testOrderId }
    })
    await prisma.stationLog.deleteMany({
      where: { orderId: testOrderId }
    })
    await prisma.order.deleteMany({
      where: {
        OR: [
          { id: testOrderId },
          { orderNumber: { startsWith: 'TEST-' } }
        ]
      }
    })
    await prisma.material.deleteMany({
      where: { id: testMaterialId }
    })
    await prisma.materialTemplate.deleteMany({
      where: { id: testStyleId }
    })
  })

  describe('GET /api/orders', () => {
    it('returns all orders with relations', async () => {
      const response = await GET()
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(Array.isArray(data)).toBe(true)
      expect(data.length).toBeGreaterThan(0)

      // Check that relations are included
      const order = data.find((o: any) => o.id === testOrderId)
      expect(order).toBeDefined()
      expect(order.style).toBeDefined()
    })
  })

  describe('POST /api/orders', () => {
    it('creates a new order with valid data', async () => {
      const request = new Request('http://localhost:3000/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          customerName: 'Test Customer 2',
          orderNumber: 'TEST-ORD-002',
          styleId: testStyleId,
          customSpecifications: 'Custom spec notes'
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(201)
      expect(data.customerName).toBe('Test Customer 2')
      expect(data.orderNumber).toBe('TEST-ORD-002')
      expect(data.styleId).toBe(testStyleId)
      expect(data.customSpecifications).toBe('Custom spec notes')
      expect(data.status).toBe('Not Started')
    })

    it('creates order with materials', async () => {
      const request = new Request('http://localhost:3000/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          customerName: 'Test Customer 3',
          orderNumber: 'TEST-ORD-003',
          materials: [
            {
              materialId: testMaterialId,
              quantity: 5,
              unitCost: 50.0
            }
          ]
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(201)
      expect(data.customerName).toBe('Test Customer 3')

      // Verify materials were created
      const orderMaterials = await prisma.orderMaterial.findMany({
        where: { orderId: data.id }
      })
      expect(orderMaterials.length).toBe(1)
      expect(orderMaterials[0].plannedQuantity).toBe(5)
      expect(orderMaterials[0].unitCost).toBe(50.0)
    })

    it('generates order number if not provided', async () => {
      const request = new Request('http://localhost:3000/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          customerName: 'Test Customer 4'
        })
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(201)
      expect(data.orderNumber).toBeDefined()
      expect(data.orderNumber).toMatch(/^ORD-/)
    })

    it('rejects invalid data', async () => {
      const request = new Request('http://localhost:3000/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          customerName: ''
        })
      })

      const response = await POST(request)
      expect(response.status).toBe(400)
    })
  })

  describe('GET /api/orders/[id]', () => {
    it('returns an order by id with relations', async () => {
      const response = await getById(
        new Request(`http://localhost:3000/api/orders/${testOrderId}`),
        { params: Promise.resolve({ id: testOrderId }) }
      )
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.id).toBe(testOrderId)
      expect(data.customerName).toBe('Test Customer')
      expect(data.style).toBeDefined()
      expect(data.materials).toBeDefined()
      expect(data.stationLogs).toBeDefined()
    })

    it('returns 404 for non-existent order', async () => {
      const response = await getById(
        new Request('http://localhost:3000/api/orders/invalid-id'),
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })

  describe('PUT /api/orders/[id]', () => {
    it('updates an order', async () => {
      const request = new Request(`http://localhost:3000/api/orders/${testOrderId}`, {
        method: 'PUT',
        body: JSON.stringify({
          customerName: 'Updated Customer Name',
          customSpecifications: 'Updated specs',
          status: 'In Progress'
        })
      })

      const response = await PUT(
        request,
        { params: Promise.resolve({ id: testOrderId }) }
      )
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data.customerName).toBe('Updated Customer Name')
      expect(data.customSpecifications).toBe('Updated specs')
      expect(data.status).toBe('In Progress')
    })

    it('rejects invalid status', async () => {
      const request = new Request(`http://localhost:3000/api/orders/${testOrderId}`, {
        method: 'PUT',
        body: JSON.stringify({
          status: 'Invalid Status'
        })
      })

      const response = await PUT(
        request,
        { params: Promise.resolve({ id: testOrderId }) }
      )

      expect(response.status).toBe(400)
    })

    it('returns 404 when updating non-existent order', async () => {
      const request = new Request('http://localhost:3000/api/orders/invalid-id', {
        method: 'PUT',
        body: JSON.stringify({
          customerName: 'Does Not Exist'
        })
      })

      const response = await PUT(
        request,
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })

  describe('DELETE /api/orders/[id]', () => {
    it('soft deletes an order by setting status to Cancelled', async () => {
      const order = await prisma.order.create({
        data: {
          orderNumber: 'TEST-ORD-DELETE',
          customerName: 'Test Delete Customer',
        }
      })

      const response = await DELETE(
        new Request(`http://localhost:3000/api/orders/${order.id}`),
        { params: Promise.resolve({ id: order.id }) }
      )

      expect(response.status).toBe(204)

      const deleted = await prisma.order.findUnique({
        where: { id: order.id }
      })
      expect(deleted?.status).toBe('Cancelled')
    })

    it('returns 404 when deleting non-existent order', async () => {
      const response = await DELETE(
        new Request('http://localhost:3000/api/orders/invalid-id'),
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })

  describe('GET /api/orders/[id]/costs', () => {
    it('calculates order costs', async () => {
      // Create a test order with materials and station logs
      const order = await prisma.order.create({
        data: {
          orderNumber: 'TEST-ORD-COSTS',
          customerName: 'Test Costs Customer',
        }
      })

      // Add order material
      await prisma.orderMaterial.create({
        data: {
          orderId: order.id,
          materialId: testMaterialId,
          plannedQuantity: 5,
          actualQuantity: 5,
          unitCost: 50.0
        }
      })

      const response = await getCosts(
        new Request(`http://localhost:3000/api/orders/${order.id}/costs`),
        { params: Promise.resolve({ id: order.id }) }
      )
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data).toHaveProperty('materialCost')
      expect(data).toHaveProperty('laborCost')
      expect(data).toHaveProperty('totalCost')
      expect(data.materialCost).toBe(250.0) // 5 * 50.0
      expect(data.laborCost).toBe(0) // No station logs yet
      expect(data.totalCost).toBe(250.0)

      // Clean up
      await prisma.orderMaterial.deleteMany({ where: { orderId: order.id } })
      await prisma.order.delete({ where: { id: order.id } })
    })

    it('returns 404 for non-existent order', async () => {
      const response = await getCosts(
        new Request('http://localhost:3000/api/orders/invalid-id/costs'),
        { params: Promise.resolve({ id: 'invalid-id' }) }
      )

      expect(response.status).toBe(404)
    })
  })
})
