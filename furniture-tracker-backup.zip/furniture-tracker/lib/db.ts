import { prisma } from './prisma'

export { prisma }

// Helper to calculate order costs
export async function calculateOrderCosts(orderId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      materials: true,
      stationLogs: {
        include: {
          station: true
        }
      }
    }
  })

  if (!order) return null

  // Calculate material costs
  const materialCost = order.materials.reduce((sum: number, om: { actualQuantity: number; unitCost: number }) => {
    return sum + (om.actualQuantity * om.unitCost)
  }, 0)

  // Calculate labor costs
  const laborCost = order.stationLogs.reduce((sum: number, log: { checkOutAt: Date | null; checkInAt: Date; station: { laborRate: number } }) => {
    if (!log.checkOutAt) return sum
    const hours = (log.checkOutAt.getTime() - log.checkInAt.getTime()) / (1000 * 60 * 60)
    return sum + (hours * log.station.laborRate)
  }, 0)

  return {
    materialCost,
    laborCost,
    totalCost: materialCost + laborCost
  }
}

// Helper to get current station for an order
export async function getCurrentStation(orderId: string) {
  const latestLog = await prisma.stationLog.findFirst({
    where: {
      orderId,
      checkOutAt: null
    },
    include: {
      station: true
    },
    orderBy: {
      checkInAt: 'desc'
    }
  })

  return latestLog?.station ?? null
}
