import StationScanner from '@/components/StationScanner'

export default function StationPage() {
  return <StationScanner />
}
