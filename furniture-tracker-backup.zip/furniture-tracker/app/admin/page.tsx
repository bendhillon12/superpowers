'use client'

import { useEffect, useState } from 'react'

interface Station {
  id: string
  name: string
}

interface Order {
  id: string
  orderNumber: string
  customerName: string
}

interface FloorData {
  [stationId: string]: {
    station: Station
    orders: (Order & { timeAtStation: number })[]
  }
}

export default function AdminDashboard() {
  const [floorData, setFloorData] = useState<FloorData>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchFloorView()
    const interval = setInterval(fetchFloorView, 5000) // Refresh every 5 seconds
    return () => clearInterval(interval)
  }, [])

  const fetchFloorView = async () => {
    try {
      const response = await fetch('/api/floor-view')
      const data = await response.json()
      setFloorData(data)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch floor view:', error)
    }
  }

  const getColorClass = (hours: number) => {
    if (hours < 4) return 'bg-green-100 border-green-400'
    if (hours < 8) return 'bg-yellow-100 border-yellow-400'
    return 'bg-red-100 border-red-400'
  }

  if (loading) {
    return <div className="text-center p-8">Loading...</div>
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Live Floor View</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.values(floorData).map(({ station, orders }) => (
          <div key={station.id} className="bg-white rounded-lg shadow p-6">
            <h2 className="text-2xl font-semibold mb-4 border-b pb-2">
              {station.name}
            </h2>

            {orders.length === 0 ? (
              <p className="text-gray-400 italic">No orders</p>
            ) : (
              <div className="space-y-2">
                {orders.map(order => (
                  <div
                    key={order.id}
                    className={`p-3 border-2 rounded ${getColorClass(order.timeAtStation)}`}
                  >
                    <div className="font-semibold">{order.orderNumber}</div>
                    <div className="text-sm text-gray-600">{order.customerName}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {order.timeAtStation.toFixed(1)}h
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
