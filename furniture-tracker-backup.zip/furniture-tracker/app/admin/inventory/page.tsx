'use client'

import { useEffect, useState } from 'react'

interface Material {
  id: string
  name: string
  type: string
  currentQuantity: number
  unitCost: number
  reorderThreshold: number
  unitOfMeasure: string
}

export default function InventoryPage() {
  const [materials, setMaterials] = useState<Material[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchMaterials()
  }, [])

  const fetchMaterials = async () => {
    try {
      setIsLoading(true)
      setError(null)
      const response = await fetch('/api/materials')

      if (!response.ok) {
        throw new Error('Failed to fetch materials')
      }

      const data = await response.json()
      setMaterials(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load materials')
    } finally {
      setIsLoading(false)
    }
  }

  const isLowStock = (material: Material) => {
    return material.currentQuantity <= material.reorderThreshold
  }

  const lowStockCount = materials.filter(isLowStock).length

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Inventory</h1>
        {lowStockCount > 0 && (
          <div className="px-4 py-2 bg-red-100 text-red-800 rounded-lg font-medium">
            {lowStockCount} item{lowStockCount !== 1 ? 's' : ''} low on stock
          </div>
        )}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded mb-6">
          {error}
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-500">
            Loading inventory...
          </div>
        ) : materials.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No materials found in inventory.
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-4 text-left font-medium">Material</th>
                <th className="p-4 text-left font-medium">Type</th>
                <th className="p-4 text-left font-medium">Quantity</th>
                <th className="p-4 text-left font-medium">Unit Cost</th>
                <th className="p-4 text-left font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {materials.map(material => {
                const lowStock = isLowStock(material)
                return (
                  <tr
                    key={material.id}
                    className={`border-b transition-colors ${
                      lowStock ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'
                    }`}
                  >
                    <td className="p-4 font-medium">{material.name}</td>
                    <td className="p-4 capitalize">{material.type}</td>
                    <td className="p-4">
                      <span className={lowStock ? 'text-red-700 font-semibold' : ''}>
                        {material.currentQuantity} {material.unitOfMeasure}
                      </span>
                    </td>
                    <td className="p-4 text-gray-700">
                      ${material.unitCost.toFixed(2)}
                    </td>
                    <td className="p-4">
                      {lowStock && (
                        <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium inline-flex items-center gap-1">
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                          </svg>
                          Low Stock
                        </span>
                      )}
                      {!lowStock && (
                        <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                          In Stock
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>

      {!isLoading && materials.length > 0 && (
        <div className="mt-4 text-sm text-gray-600">
          Showing {materials.length} material{materials.length !== 1 ? 's' : ''}
        </div>
      )}
    </div>
  )
}
