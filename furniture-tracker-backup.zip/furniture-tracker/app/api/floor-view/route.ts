import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

type StationWithLogs = {
  id: string
  name: string
  stationLogs: {
    checkInAt: Date
    order: {
      id: string
      orderNumber: string
      customerName: string
    }
  }[]
}

type FloorData = {
  [stationId: string]: {
    station: {
      id: string
      name: string
    }
    orders: {
      id: string
      orderNumber: string
      customerName: string
      timeAtStation: number
    }[]
  }
}

export async function GET() {
  try {
    const stations = await prisma.station.findMany({
      where: { active: true },
      orderBy: { sortOrder: 'asc' },
      include: {
        stationLogs: {
          where: {
            checkOutAt: null
          },
          include: {
            order: true
          }
        }
      }
    })

    const floorData = stations.reduce((acc: FloorData, station: StationWithLogs) => {
      acc[station.id] = {
        station: {
          id: station.id,
          name: station.name
        },
        orders: station.stationLogs.map((log) => {
          const hours = (Date.now() - log.checkInAt.getTime()) / (1000 * 60 * 60)
          return {
            id: log.order.id,
            orderNumber: log.order.orderNumber,
            customerName: log.order.customerName,
            timeAtStation: hours
          }
        })
      }
      return acc
    }, {} as FloorData)

    return NextResponse.json(floorData)
  } catch (error) {
    console.error('Floor view API error:', error)
    return NextResponse.json({ error: 'Failed to fetch floor view' }, { status: 500 })
  }
}
