import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createStationSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  laborRate: z.number().min(0),
  sortOrder: z.number().int().min(0).optional(),
})

export async function GET() {
  try {
    const stations = await prisma.station.findMany({
      where: { active: true },
      orderBy: { sortOrder: 'asc' }
    })
    return NextResponse.json(stations)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch stations' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const validated = createStationSchema.parse(body)
    const station = await prisma.station.create({
      data: {
        name: validated.name,
        description: validated.description,
        laborRate: validated.laborRate,
        sortOrder: validated.sortOrder || 0,
      }
    })
    return NextResponse.json(station, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    return NextResponse.json({ error: 'Failed to create station' }, { status: 500 })
  }
}
