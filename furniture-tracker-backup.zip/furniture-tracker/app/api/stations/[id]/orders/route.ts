import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const stationId = params.id

    // Verify station exists
    const station = await prisma.station.findUnique({
      where: { id: stationId }
    })

    if (!station) {
      return NextResponse.json(
        { error: 'Station not found' },
        { status: 404 }
      )
    }

    // Find all orders currently checked in at this station
    // (stationLogs where checkOutAt is null and stationId matches)
    const stationLogs = await prisma.stationLog.findMany({
      where: {
        stationId,
        checkOutAt: null
      },
      include: {
        order: true
      }
    })

    // Extract unique orders
    const orders = stationLogs.map((log: { order: any }) => log.order)

    return NextResponse.json(orders)
  } catch (error) {
    console.error('Failed to fetch orders at station:', error)
    return NextResponse.json(
      { error: 'Failed to fetch orders at station' },
      { status: 500 }
    )
  }
}
