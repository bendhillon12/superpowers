import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const scanSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  stationId: z.string().min(1, 'Station ID is required')
})

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const validated = scanSchema.parse(body)
    const { orderId, stationId } = validated

    // Verify order and station exist before transaction
    const order = await prisma.order.findUnique({
      where: { id: orderId }
    })

    if (!order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      )
    }

    const station = await prisma.station.findUnique({
      where: { id: stationId }
    })

    if (!station) {
      return NextResponse.json(
        { error: 'Station not found' },
        { status: 404 }
      )
    }

    // Wrap all operations in a transaction to prevent race conditions
    const result = await prisma.$transaction(async (tx: any) => {
      // Find current station for this order (within transaction)
      const currentStation = await tx.stationLog.findFirst({
        where: {
          orderId,
          checkOutAt: null
        },
        include: {
          station: true
        }
      })

      // Case 1: Order not at any station -> CHECK IN
      if (!currentStation) {
        const log = await tx.stationLog.create({
          data: {
            orderId,
            stationId
          }
        })

        // Update order status to "In Progress" on first check-in
        await tx.order.update({
          where: { id: orderId },
          data: { status: 'In Progress' }
        })

        return {
          action: 'CHECK_IN' as const,
          log,
          message: `Order checked in to ${station.name}`
        }
      }

      // Case 2: Order at same station -> CHECK OUT
      if (currentStation.stationId === stationId) {
        const updatedLog = await tx.stationLog.update({
          where: { id: currentStation.id },
          data: { checkOutAt: new Date() }
        })

        return {
          action: 'CHECK_OUT' as const,
          log: updatedLog,
          message: `Order checked out from ${currentStation.station.name}`
        }
      }

      // Case 3: Order at different station -> AUTO CHECK OUT + CHECK IN (TRANSFER)
      // Check out from old station
      await tx.stationLog.update({
        where: { id: currentStation.id },
        data: { checkOutAt: new Date() }
      })

      // Check in to new station
      const newLog = await tx.stationLog.create({
        data: {
          orderId,
          stationId
        }
      })

      return {
        action: 'TRANSFER' as const,
        log: newLog,
        message: `Order moved from ${currentStation.station.name} to ${station.name}`
      }
    })

    return NextResponse.json(result)

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.issues },
        { status: 400 }
      )
    }
    if (error instanceof Error) {
      console.error('Scan failed:', error.message)
    }
    return NextResponse.json(
      { error: 'Scan failed' },
      { status: 500 }
    )
  }
}
