import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createOrderSchema = z.object({
  customerName: z.string().min(1, 'Customer name is required'),
  orderNumber: z.string().optional(),
  styleId: z.string().optional(),
  customSpecifications: z.string().optional(),
  materials: z.array(z.object({
    materialId: z.string(),
    quantity: z.number().min(0),
    unitCost: z.number().min(0)
  })).optional()
})

export async function GET() {
  try {
    const orders = await prisma.order.findMany({
      include: {
        style: true,
        materials: {
          include: {
            material: true
          }
        },
        stationLogs: {
          include: {
            station: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(orders)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const validated = createOrderSchema.parse(body)

    // Generate unique order number if not provided
    // Use timestamp + random suffix to avoid collisions
    const orderNumber = validated.orderNumber ?? `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`

    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerName: validated.customerName,
        styleId: validated.styleId,
        customSpecifications: validated.customSpecifications,
      }
    })

    // If materials provided, create order materials
    if (validated.materials && validated.materials.length > 0) {
      await prisma.orderMaterial.createMany({
        data: validated.materials.map((m) => ({
          orderId: order.id,
          materialId: m.materialId,
          plannedQuantity: m.quantity,
          unitCost: m.unitCost
        }))
      })
    }

    // Fetch the created order with all relations to return consistent response
    const orderWithRelations = await prisma.order.findUnique({
      where: { id: order.id },
      include: {
        style: true,
        materials: {
          include: {
            material: true
          }
        },
        stationLogs: {
          include: {
            station: true
          }
        }
      }
    })

    return NextResponse.json(orderWithRelations, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    // Handle unique constraint violation (duplicate order number)
    if (error instanceof Error && 'code' in error && error.code === 'P2002') {
      return NextResponse.json(
        { error: 'Order number already exists' },
        { status: 400 }
      )
    }
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}
