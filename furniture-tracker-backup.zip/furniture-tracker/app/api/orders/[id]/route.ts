import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const updateOrderSchema = z.object({
  customerName: z.string().min(1).optional(),
  orderNumber: z.string().min(1).optional(),
  styleId: z.string().nullable().optional(),
  customSpecifications: z.string().nullable().optional(),
  status: z.enum(['Not Started', 'In Progress', 'Completed', 'Cancelled']).optional(),
  completedAt: z.string().datetime().nullable().optional(),
})

type RouteContext = {
  params: Promise<{ id: string }>
}

export async function GET(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const order = await prisma.order.findUnique({
      where: { id },
      include: {
        style: true,
        materials: {
          include: {
            material: true
          }
        },
        stationLogs: {
          include: {
            station: true
          },
          orderBy: {
            checkInAt: 'desc'
          }
        }
      }
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    return NextResponse.json(order)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch order' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const body = await request.json()
    const validated = updateOrderSchema.parse(body)

    // Convert completedAt string to Date if provided
    const updateData: any = { ...validated }
    if (validated.completedAt !== undefined) {
      updateData.completedAt = validated.completedAt ? new Date(validated.completedAt) : null
    }

    const order = await prisma.order.update({
      where: { id },
      data: updateData
    })

    return NextResponse.json(order)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    // Prisma will throw if record not found
    if ((error as any).code === 'P2025') {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params

    // Soft delete by setting status to Cancelled
    await prisma.order.update({
      where: { id },
      data: { status: 'Cancelled' }
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    // Prisma will throw if record not found
    if ((error as any).code === 'P2025') {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to delete order' }, { status: 500 })
  }
}
