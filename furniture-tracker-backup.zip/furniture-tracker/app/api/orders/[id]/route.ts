import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const updateOrderSchema = z.object({
  customerName: z.string().min(1).optional(),
  orderNumber: z.string().min(1).optional(),
  styleId: z.string().nullable().optional(),
  customSpecifications: z.string().nullable().optional(),
  status: z.enum(['Not Started', 'In Progress', 'Completed', 'Cancelled']).optional(),
  completedAt: z.string().datetime().nullable().optional(),
})

type RouteContext = {
  params: Promise<{ id: string }>
}

export async function GET(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const order = await prisma.order.findUnique({
      where: { id },
      include: {
        style: true,
        materials: {
          include: {
            material: true
          }
        },
        stationLogs: {
          include: {
            station: true
          },
          orderBy: {
            checkInAt: 'desc'
          }
        }
      }
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    return NextResponse.json(order)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch order' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const body = await request.json()
    const validated = updateOrderSchema.parse(body)

    // Fetch current order to validate business logic
    const currentOrder = await prisma.order.findUnique({
      where: { id }
    })

    if (!currentOrder) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    // Prevent updates to cancelled orders
    if (currentOrder.status === 'Cancelled') {
      return NextResponse.json(
        { error: 'Cannot update cancelled orders' },
        { status: 400 }
      )
    }

    // Validate status transitions
    if (validated.status) {
      const validTransitions: Record<string, string[]> = {
        'Not Started': ['In Progress', 'Cancelled'],
        'In Progress': ['Completed', 'Cancelled'],
        'Completed': [], // Completed orders cannot transition to other states
        'Cancelled': [] // Cancelled orders cannot transition (prevented above)
      }

      const allowedStatuses = validTransitions[currentOrder.status] || []
      if (!allowedStatuses.includes(validated.status)) {
        return NextResponse.json(
          { error: `Cannot transition from ${currentOrder.status} to ${validated.status}` },
          { status: 400 }
        )
      }
    }

    // Validate completedAt is only set when status is Completed
    if (validated.completedAt !== undefined && validated.status !== 'Completed') {
      return NextResponse.json(
        { error: 'completedAt can only be set when status is Completed' },
        { status: 400 }
      )
    }

    // Build update data with proper typing
    type UpdateData = {
      customerName?: string
      orderNumber?: string
      styleId?: string | null
      customSpecifications?: string | null
      status?: string
      completedAt?: Date | null
    }

    const updateData: UpdateData = {}

    if (validated.customerName !== undefined) updateData.customerName = validated.customerName
    if (validated.orderNumber !== undefined) updateData.orderNumber = validated.orderNumber
    if (validated.styleId !== undefined) updateData.styleId = validated.styleId
    if (validated.customSpecifications !== undefined) updateData.customSpecifications = validated.customSpecifications
    if (validated.status !== undefined) {
      updateData.status = validated.status
      // Auto-set completedAt when marking as Completed
      if (validated.status === 'Completed' && !currentOrder.completedAt) {
        updateData.completedAt = new Date()
      }
    }
    if (validated.completedAt !== undefined) {
      updateData.completedAt = validated.completedAt ? new Date(validated.completedAt) : null
    }

    const order = await prisma.order.update({
      where: { id },
      data: updateData
    })

    return NextResponse.json(order)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 })
    }
    // Prisma will throw if record not found
    if (error instanceof Error && 'code' in error && error.code === 'P2025') {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params

    // Soft delete by setting status to Cancelled
    await prisma.order.update({
      where: { id },
      data: { status: 'Cancelled' }
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    // Prisma will throw if record not found
    if (error instanceof Error && 'code' in error && error.code === 'P2025') {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    return NextResponse.json({ error: 'Failed to delete order' }, { status: 500 })
  }
}
