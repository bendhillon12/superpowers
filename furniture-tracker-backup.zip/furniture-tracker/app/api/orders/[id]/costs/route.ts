import { NextResponse } from 'next/server'
import { calculateOrderCosts } from '@/lib/db'

type RouteContext = {
  params: Promise<{ id: string }>
}

export async function GET(
  request: Request,
  context: RouteContext
) {
  try {
    const { id } = await context.params
    const costs = await calculateOrderCosts(id)

    if (!costs) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    return NextResponse.json(costs)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to calculate costs' }, { status: 500 })
  }
}
