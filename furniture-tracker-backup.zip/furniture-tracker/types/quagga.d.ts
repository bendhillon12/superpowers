declare module 'quagga' {
  export interface QuaggaJSConfigObject {
    inputStream?: {
      type?: string
      target?: HTMLElement | null
      constraints?: {
        facingMode?: string
        [key: string]: any
      }
    }
    decoder?: {
      readers?: string[]
      [key: string]: any
    }
    [key: string]: any
  }

  export interface QuaggaJSResultObject {
    codeResult: {
      code?: string
      [key: string]: any
    }
    [key: string]: any
  }

  export default class Quagga {
    static init(
      config: QuaggaJSConfigObject,
      callback: (err: any) => void
    ): void
    static start(): void
    static stop(): void
    static onDetected(callback: (result: QuaggaJSResultObject) => void): void
  }
}
