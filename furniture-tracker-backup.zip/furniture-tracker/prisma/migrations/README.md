# Database Migrations

This directory contains Prisma database migrations for the furniture-tracker application.

## Note

The initial migration (20260115000000_init) was created as a placeholder due to environment limitations during development.

## Running Migrations in Production

To apply migrations in your production environment:

```bash
# Generate Prisma Client
npx prisma generate

# Apply all pending migrations
npx prisma migrate deploy
```

## Development

For development environments, use:

```bash
# Create and apply a new migration
npx prisma migrate dev --name <migration_name>

# Reset database and apply all migrations
npx prisma migrate reset
```

## Initial Setup

If starting fresh, the `20260115000000_init` migration creates all necessary tables:
- stations
- materials
- material_templates
- template_materials
- orders
- order_materials
- station_logs

After running migrations, seed initial data with:
```bash
node scripts/seed-stations.js
```
