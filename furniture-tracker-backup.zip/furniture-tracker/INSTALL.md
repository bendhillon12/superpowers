# Quick Installation Guide

This guide will help you install the Furniture Tracker application on your wife's computer in just a few steps.

## Prerequisites

Before running the installation script, make sure you have:

1. **Node.js 18 or higher** installed
   - Download from: https://nodejs.org/
   - Choose the LTS (Long Term Support) version
   - During installation, check the box to "Add to PATH"

2. **PostgreSQL 15 or higher** installed
   - **Windows:** https://www.postgresql.org/download/windows/
   - **Mac:** https://postgresapp.com/ or `brew install postgresql@15`
   - **Linux:** `sudo apt install postgresql postgresql-contrib` (Ubuntu/Debian)
   - Remember the password you set during installation

3. Download or extract the `furniture-tracker` folder to a location on the computer

## Installation Steps

### For Windows:

1. Open **PowerShell as Administrator**
   - Press `Windows + X`
   - Select "Windows PowerShell (Admin)" or "Terminal (Admin)"

2. Navigate to the furniture-tracker folder:
   ```powershell
   cd C:\path\to\furniture-tracker
   ```

3. Run the installation script:
   ```powershell
   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\install.ps1
   ```

4. Follow the prompts:
   - Database host: (press Enter for localhost)
   - Database port: (press Enter for 5432)
   - Database name: (press Enter for furniture_tracker)
   - Database username: (press Enter for postgres)
   - Database password: (enter the password you set during PostgreSQL installation)
   - Seed sample data: Type `y` and press Enter

5. When asked "Start the application now?", type `y`

6. The application is now running!
   - Open a browser and go to: http://localhost:3000/admin
   - Workers can access: http://localhost:3000/station

### For Mac/Linux:

1. Open **Terminal**

2. Navigate to the furniture-tracker folder:
   ```bash
   cd /path/to/furniture-tracker
   ```

3. Make the script executable:
   ```bash
   chmod +x install.sh
   ```

4. Run the installation script:
   ```bash
   ./install.sh
   ```

5. Follow the prompts (same as Windows above)

6. The application is now running!

## Accessing from Other Devices (Tablets/Phones)

The installation script will show you the local IP address. For example: `192.168.1.100`

Workers can access the scanning interface from their tablets by visiting:
- `http://192.168.1.100:3000/station`

Admin can access the dashboard from any device on the network:
- `http://192.168.1.100:3000/admin`

**Important:** Make sure all devices are on the same WiFi network.

## Starting the Application After Installation

If you close the application, you can start it again:

### Quick Start:
```bash
cd /path/to/furniture-tracker
npm start
```

The application will be available at `http://localhost:3000`

### Run as a Background Service (Recommended for Production):

**Windows:**
The installer can set this up as a Windows service that starts automatically.
If you skipped this during installation, run:
```powershell
.\install.ps1
```
And choose "yes" when asked about Windows service installation.

**Mac (using pm2):**
```bash
npm install -g pm2
pm2 start npm --name "furniture-tracker" -- start
pm2 save
pm2 startup  # Follow the instructions shown
```

**Linux (using systemd):**
Create `/etc/systemd/system/furniture-tracker.service`:
```ini
[Unit]
Description=Furniture Tracker
After=network.target postgresql.service

[Service]
Type=simple
User=your-username
WorkingDirectory=/path/to/furniture-tracker
ExecStart=/usr/bin/npm start
Restart=always
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl enable furniture-tracker
sudo systemctl start furniture-tracker
```

## Firewall Configuration

If workers can't access from tablets, you may need to allow port 3000 through the firewall:

**Windows:**
```powershell
New-NetFirewallRule -DisplayName "Furniture Tracker" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow
```

**Mac:**
```bash
# Go to System Preferences > Security & Privacy > Firewall > Firewall Options
# Allow incoming connections for Node.js
```

**Linux:**
```bash
sudo ufw allow 3000/tcp
```

## Troubleshooting

### "Cannot connect to database"
- Make sure PostgreSQL is running
- On Windows: Check Services (services.msc) for "postgresql" service
- On Mac: `brew services start postgresql@15`
- On Linux: `sudo systemctl start postgresql`
- Verify the database password in the `.env` file

### "Port 3000 already in use"
Another application is using port 3000. Either:
- Close that application
- Or change the port in `.env` file: `PORT=3001`

### "Camera not working for barcode scanning"
- Grant camera permissions in the browser
- Use HTTPS or localhost (required for camera access)
- Use manual entry as fallback (button in the scanning interface)

### Workers can't access from tablets
- Verify devices are on the same WiFi network
- Check firewall settings (see above)
- Try accessing by IP address: `http://192.168.1.x:3000/station`

## Next Steps

1. **Access the admin dashboard**: http://localhost:3000/admin
2. **Create stations** (or modify the seeded ones)
3. **Add materials** to inventory
4. **Create your first order**
5. **Print station barcodes** - You'll need the station IDs from the database
6. **Have workers test** the scanning interface at: http://your-ip:3000/station

## Support

For more detailed documentation, see:
- `README.md` - Complete project documentation
- `DEPLOYMENT.md` - Advanced deployment options

## Uninstallation

If you need to uninstall:

1. Stop the application (Ctrl+C or stop the service)
2. Remove the furniture-tracker folder
3. Optionally drop the database:
   ```bash
   dropdb furniture_tracker
   ```

For Windows service uninstall:
```powershell
node uninstall-service.js  # If you have this file
```

Or manually remove from Windows Services.
