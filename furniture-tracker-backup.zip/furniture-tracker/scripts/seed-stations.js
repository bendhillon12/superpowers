const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  const stations = [
    { name: 'Cutting', description: 'Cut materials to size', laborRate: 25, sortOrder: 1 },
    { name: 'Assembly', description: 'Assemble furniture pieces', laborRate: 30, sortOrder: 2 },
    { name: 'Finishing', description: 'Final touches and quality check', laborRate: 35, sortOrder: 3 },
  ]

  for (const station of stations) {
    await prisma.station.upsert({
      where: { name: station.name },
      update: {},
      create: station
    })
  }

  console.log('✓ Seeded 3 stations')

  // Add sample materials
  const materials = [
    { name: 'Oak Plywood 4x8', type: 'wood', unitOfMeasure: 'sheets', currentQuantity: 50, unitCost: 45, reorderThreshold: 10 },
    { name: 'Italian Leather - Brown', type: 'leather', unitOfMeasure: 'yards', currentQuantity: 100, unitCost: 25, reorderThreshold: 20 },
    { name: 'Upholstery Fabric - Gray', type: 'fabric', unitOfMeasure: 'yards', currentQuantity: 75, unitCost: 15, reorderThreshold: 15 },
  ]

  for (const material of materials) {
    await prisma.material.upsert({
      where: { name: material.name },
      update: {},
      create: material
    })
  }

  console.log('✓ Seeded 3 materials')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
