# 🎯 QUICK REFERENCE CARD
## Station Scanning - Print and Laminate This!

---

# 📱 HOW TO SCAN AT YOUR STATION

## 1️⃣ SELECT YOUR STATION
Tap your station button when you first start

## 2️⃣ TAP "START SCANNING"
Camera will activate

## 3️⃣ SCAN THE BARCODE
Point camera at order barcode on work piece

## 4️⃣ LOOK FOR THE MESSAGE

### ✅ GREEN = SUCCESS
- **"Order checked in"** → You just started this order
- **"Order checked out"** → You just finished this order
- **"Order moved"** → Order transferred to your station

### ❌ RED = ERROR
- **"Order not found"** → Try scanning again
- **"Station not found"** → Wrong station selected

---

# 🔄 WHEN TO SCAN

| When | Action |
|------|--------|
| 🟢 **Start working on order** | SCAN ONCE |
| 🔴 **Finish working on order** | SCAN AGAIN |
| 🔄 **Order from another station** | SCAN ONCE (auto-transfer) |

---

# ⚠️ PROBLEMS?

### Camera Not Working?
→ Tap **"Enter Manually"** and type order number

### Wrong Station?
→ Tap **"Change Station"** at top of screen

### Still Need Help?
→ Call Supervisor: **[PHONE NUMBER]**

---

# ✓ REMEMBER

✓ **Scan when you START**
✓ **Scan when you FINISH**
✓ **That's it!**

---

_Keep this card at your station for quick reference_

---

# 📋 FOR SUPERVISORS ONLY

## Common Worker Issues

| Issue | Solution |
|-------|----------|
| Forgot to scan | Have them scan now, or fix in admin |
| Scanned twice by mistake | That's okay - second scan checks out |
| Tablet frozen | Restart tablet, reconnect to WiFi |
| Barcode damaged | Use manual entry or print new barcode |

## Admin Quick Access
**Dashboard:** http://localhost:3000/admin
**Floor View:** Shows all orders at all stations
**Auto-refresh:** Every 5 seconds

## Contact Info
- **Technical Support:** [PHONE]
- **Admin Dashboard:** [PHONE]
- **WiFi Name:** [NETWORK NAME]
- **WiFi Password:** [PASSWORD]

---

_Post this at each station • Laminate for durability_
