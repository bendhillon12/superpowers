# 🔧 TROUBLESHOOTING FLOWCHART
## Visual Guide for Common Problems

---

## Problem: TABLET NOT RESPONDING

```
Is tablet powered on?
├─ NO → Charge tablet → Plug into power
└─ YES ↓

Can you see the app?
├─ NO → Open browser → Go to http://[server-ip]:3000/station
└─ YES ↓

Is it frozen/stuck?
├─ YES → Long-press power button → Restart tablet
└─ NO ↓

Check WiFi connection
├─ Not connected → Connect to [NETWORK NAME]
└─ Connected ↓

Still not working?
└─ Call supervisor
```

---

## Problem: BARCODE WON'T SCAN

```
Is camera working?
├─ NO → ┬─ Clean camera lens
│       ├─ Check camera permissions
│       └─ Use "Enter Manually" option
└─ YES ↓

Is barcode visible/clear?
├─ NO → ┬─ Print new barcode
│       ├─ Clean work surface
│       └─ Use "Enter Manually" option
└─ YES ↓

Are you holding steady?
├─ NO → Hold tablet 6 inches from barcode
└─ YES ↓

Is lighting good?
├─ NO → Move to better lit area
└─ YES ↓

Still won't scan?
└─ Use "Enter Manually" → Type order number
```

---

## Problem: WRONG ORDER SCANNED

```
What happened?
├─ Scanned at wrong station
│   └─ Scan again immediately (checks out)
│       └─ Go to correct station and scan
│
├─ Scanned wrong order number
│   └─ Scan the CORRECT order immediately
│       └─ Tell supervisor to fix in admin
│
└─ Scanned twice by accident
    └─ That's okay!
        └─ Second scan just checks out
            └─ Scan again if needed to check back in
```

---

## Problem: ORDER NOT SHOWING ON SCREEN

```
Did you scan the order?
├─ NO → Scan the order barcode
└─ YES ↓

Did you see green "success" message?
├─ NO → ┬─ Scan didn't work
│       └─ Try scanning again
└─ YES ↓

Are you looking at correct station?
├─ NO → Tap "Change Station"
└─ YES ↓

Wait 5 seconds for screen refresh
└─ Still not showing?
    └─ Call supervisor (may be at different station)
```

---

## Problem: CAN'T ACCESS ADMIN DASHBOARD

```
Open web browser
└─ Go to: http://localhost:3000/admin

Can't connect?
├─ From same computer as server
│   ├─ Is application running? → Run: npm start
│   └─ Check: http://localhost:3000/admin
│
└─ From different computer
    ├─ On same WiFi network?
    │   └─ NO → Connect to same network
    ├─ Server computer on?
    │   └─ NO → Turn on server computer
    └─ Use server IP: http://[IP]:3000/admin

Still can't connect?
├─ Check firewall settings
├─ Restart application
└─ Restart server computer
```

---

## Problem: ORDER STUCK AT STATION (RED CARD)

```
Check floor view dashboard
└─ Red card = order at station 8+ hours

Talk to worker at that station
├─ Is work complete?
│   ├─ YES → Worker forgot to scan out
│   │        └─ Have them scan now
│   └─ NO → Why not?
│            ├─ Missing materials
│            ├─ Waiting for information
│            ├─ Quality issue
│            └─ Workload too high
│
└─ Is worker absent?
    └─ Reassign work or scan out manually
```

---

## Problem: LOW STOCK WARNING

```
See "⚠️ Low Stock" in inventory?
└─ YES ↓

Check current quantity
├─ Below reorder threshold
│   └─ Order more materials NOW
│       ├─ Call supplier
│       ├─ Place order
│       └─ Note expected delivery date
│
├─ Shipment on the way?
│   └─ Track shipment
│       └─ Update quantity when received
│
└─ Recently counted?
    └─ Physical count may be wrong
        └─ Recount inventory
            └─ Update in system
```

---

## Problem: DATABASE/SYSTEM ERRORS

```
See error message?
└─ Read the message carefully

Error says "Database connection failed"?
├─ Check PostgreSQL is running
│   ├─ Windows: Check Services (services.msc)
│   ├─ Mac: brew services list
│   └─ Linux: systemctl status postgresql
│
└─ Restart PostgreSQL service

Error says "Port already in use"?
├─ Another app using port 3000
└─ Change port in .env file
    └─ PORT=3001
        └─ Restart application

Error says "Prisma client not found"?
└─ Run: npx prisma generate
    └─ Then: npm start

Other errors?
├─ Restart application: Ctrl+C → npm start
├─ Check .env file configuration
└─ Review DEPLOYMENT.md troubleshooting
```

---

## Problem: WORKERS NOT SCANNING CONSISTENTLY

```
This is a training issue:

Week 1: Training Phase
├─ Post WORKER-GUIDE at each station
├─ Practice with test orders
├─ Admin watches floor view daily
└─ Praise accurate scanning

Week 2-3: Reinforcement
├─ Check floor view matches reality
├─ Address missed scans quickly
├─ Remind workers why it matters
└─ Track improvement

Week 4+: Maintenance
├─ Floor view should be accurate
├─ Occasional reminders as needed
└─ New workers get training

If still problems:
├─ One-on-one training for specific workers
├─ Simplify process if possible
└─ Consider rewards for accuracy
```

---

## Problem: CUSTOMER WANTS ORDER STATUS

```
Customer calls asking about order
└─ Get order number from customer

Go to admin dashboard
└─ Click "Orders"
    └─ Find order in list

Check status:
├─ "Not Started"
│   └─ Tell customer: "Order created, will start production soon"
│
├─ "In Progress"
│   ├─ Check floor view to see current station
│   ├─ Check time at current station
│   └─ Tell customer: "Order is at [Station], approximately [X] hours to completion"
│
├─ "Completed"
│   └─ Tell customer: "Order is ready for pickup"
│
└─ "Cancelled"
    └─ Investigate why → Talk to customer
```

---

## Quick Diagnosis Decision Tree

```
What's the main symptom?

Technical Issue (tablet/app)
└─ See "TABLET NOT RESPONDING" flowchart

Scanning Problem
└─ See "BARCODE WON'T SCAN" flowchart

Wrong Data
└─ See "WRONG ORDER SCANNED" flowchart

System Performance
└─ See "DATABASE/SYSTEM ERRORS" flowchart

Process Problem
└─ See "WORKERS NOT SCANNING" flowchart

Inventory Issue
└─ See "LOW STOCK WARNING" flowchart

Order Tracking
└─ See "CUSTOMER WANTS STATUS" flowchart
```

---

## 🆘 When to Call for Help

### Call Supervisor Immediately:
- ❌ Tablet completely broken
- ❌ Server computer crashed
- ❌ Multiple workers reporting issues
- ❌ Database completely down
- ❌ Critical order stuck

### Can Wait Until End of Shift:
- ⚠️ Minor scanning issue (used manual entry)
- ⚠️ One worker forgot to scan (you fixed it)
- ⚠️ Cosmetic issues (display glitch)

### Next Day is Fine:
- ℹ️ Suggestions for improvements
- ℹ️ Feature requests
- ℹ️ Training questions

---

## Emergency Contact Info

**Technical Support:** [PHONE NUMBER]
**Supervisor:** [PHONE NUMBER]
**Database Admin:** [PHONE NUMBER]
**After Hours:** [PHONE NUMBER]

---

## Preventive Maintenance Checklist

### Daily:
- [ ] Check all tablets are charged
- [ ] Verify server is running
- [ ] Review floor view for accuracy

### Weekly:
- [ ] Clean tablet cameras
- [ ] Check barcode condition
- [ ] Review inventory levels
- [ ] Back up database

### Monthly:
- [ ] Deep clean tablets
- [ ] Replace worn barcodes
- [ ] Update software if needed
- [ ] Review worker training

---

_Keep this flowchart near admin computer for quick reference_
_Updated: January 2026_
