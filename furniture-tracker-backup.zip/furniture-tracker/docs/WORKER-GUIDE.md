# 📱 WORKER GUIDE - Station Scanning

## How to Use the Tablet at Your Station

### **Step 1: Open the App**
- Tap the browser icon on the tablet
- The scanning page should open automatically
- You'll see: **"Select Your Station"**

---

### **Step 2: Select Your Station**
- Tap the **BIG BUTTON** with your station name:
  - 🔪 **CUTTING**
  - 🔨 **ASSEMBLY**
  - ✨ **FINISHING**

---

### **Step 3: Start Scanning**
- Tap the **"START SCANNING"** button
- Point the camera at the order barcode
- **OR** tap **"Enter Manually"** to type the order number

---

### **Step 4: What Happens**

#### ✅ **GREEN Message** - Success!
- **"Order checked in"** = Work order just arrived at your station
- **"Order checked out"** = You marked work order as done
- **"Order moved"** = Work order transferred from another station

#### ❌ **RED Message** - Problem!
- **"Order not found"** = Invalid barcode, try again
- **"Station not found"** = Wrong station selected

---

### **What You See on Screen**

**Orders Currently at Your Station:**
```
📦 Order ORD-12345
📦 Order ORD-12346
📦 Order ORD-12347
```

This shows what work you have at your station right now.

---

## 🔄 **Common Scenarios**

### **Starting Work on New Order:**
1. Scan the order barcode
2. See: ✅ "Order checked in to [Your Station]"
3. Order appears in your list
4. Do the work!

### **Finishing Work:**
1. Scan the same order barcode again
2. See: ✅ "Order checked out from [Your Station]"
3. Order disappears from your list
4. Move physical work to next station

### **Order from Another Station:**
1. Scan an order that's at a different station
2. See: ✅ "Order moved from [Old Station] to [Your Station]"
3. System automatically checked it out from old station
4. Now it's at your station!

---

## ⚠️ **Troubleshooting**

### **Camera Not Working?**
- Tap **"Enter Manually"**
- Type the order number from the barcode
- Tap **"Submit"**

### **Wrong Station Selected?**
- Tap **"Change Station"** button at top
- Select the correct station

### **Barcode Won't Scan?**
1. Clean the camera lens
2. Make sure barcode is in good condition (not torn/smudged)
3. Hold tablet steady, about 6 inches from barcode
4. Try manual entry if still not working

### **Red Error Message?**
- Read the message
- Try scanning again
- If problem continues, tell your supervisor

---

## 📋 **Important Notes**

✓ **Always scan when you START work on an order**
✓ **Always scan when you FINISH work on an order**
✓ **Don't scan orders not at your station (unless moving them)**
✓ **If tablet freezes, tell supervisor - don't restart it**

---

## 🆘 **Need Help?**

**Call/Text Supervisor:** [PHONE NUMBER HERE]

**Common Questions:**
- "What if I forget to scan?" → Tell supervisor, they can fix it in admin
- "What if I scan twice?" → That's okay! Second scan checks it out
- "Can I see order details?" → No, workers only see order numbers. Admin has all details.

---

# 🎯 **QUICK REFERENCE**

| Action | What to Do |
|--------|-----------|
| Start work on order | **SCAN ONCE** |
| Finish work on order | **SCAN AGAIN** |
| Check what's at my station | **LOOK AT LIST** |
| Camera not working | **TAP "ENTER MANUALLY"** |
| Wrong station | **TAP "CHANGE STATION"** |
| Need help | **CALL SUPERVISOR** |

---

**Remember:** The app tracks everything automatically. Just scan when you start and scan when you finish. That's it! 🎉

---

_Last Updated: January 2026_
_Questions? Ask your supervisor_
