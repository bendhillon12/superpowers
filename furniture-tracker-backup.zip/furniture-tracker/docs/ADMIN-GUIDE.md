# 👨‍💼 ADMIN USER GUIDE
## Furniture Manufacturing Tracker - Complete Admin Documentation

---

## 📑 Table of Contents

1. [Getting Started](#getting-started)
2. [Floor View Dashboard](#floor-view-dashboard)
3. [Managing Orders](#managing-orders)
4. [Managing Inventory](#managing-inventory)
5. [Understanding Workflows](#understanding-workflows)
6. [Reports and Data](#reports-and-data)
7. [Troubleshooting](#troubleshooting)
8. [Tips and Best Practices](#tips-and-best-practices)

---

## 🚀 Getting Started

### Accessing the Admin Dashboard

1. **Open your web browser** (Chrome, Firefox, or Edge recommended)
2. **Go to:** `http://localhost:3000/admin`
   - Or from another computer: `http://[server-ip]:3000/admin`
3. **Bookmark this page** for quick access

### Admin Dashboard Overview

When you log in, you'll see the **Navigation Bar** at the top:

```
[Floor View] [Orders] [Inventory] [Reports] [Settings]
```

- **Floor View** = See all orders at each station in real-time
- **Orders** = Create new orders, view order history
- **Inventory** = Track materials and supplies
- **Reports** = (Future feature) View reports and analytics
- **Settings** = (Future feature) Configure system settings

---

## 📊 Floor View Dashboard

**Purpose:** Real-time overview of your entire manufacturing floor

### What You See

The floor view shows **all work stations** with **orders currently at each station**.

#### Station Cards Display:
```
┌──────────────────────────────┐
│  🔪 CUTTING                   │
│                              │
│  📦 ORD-001234               │
│      Customer: Smith         │
│      Time: 2.3h              │
│                              │
│  📦 ORD-001235               │
│      Customer: Johnson       │
│      Time: 5.8h              │
└──────────────────────────────┘
```

#### Color Coding (Time at Station):
- 🟢 **Green Background** = Less than 4 hours (normal)
- 🟡 **Yellow Background** = 4-8 hours (getting long)
- 🔴 **Red Background** = More than 8 hours (attention needed!)

### How to Use Floor View

**Monitor Workflow:**
- Check which stations are busy or idle
- See if any orders are stuck (red cards)
- Balance workload between stations

**Identify Bottlenecks:**
- If one station has many orders, that's your bottleneck
- Red cards indicate orders sitting too long
- Consider reassigning workers or investigating delays

**Auto-Refresh:**
- Page refreshes automatically every 5 seconds
- Always shows current status
- No need to manually reload

### Common Actions

**See All Orders at a Station:**
- Just look at that station's card
- Orders listed from oldest to newest

**Check Order Details:**
- Note the order number
- Go to Orders page to see full details

**Print for Meetings:**
- Press `Ctrl+P` (Windows) or `Cmd+P` (Mac)
- Print the current floor view for team meetings

---

## 📦 Managing Orders

**Purpose:** Create new work orders and track existing ones

### Creating a New Order

1. **Click "Orders"** in the navigation bar
2. **Click "+ New Order"** button (blue, top right)
3. **Fill in the form:**

   ```
   Order Number: [Optional - auto-generated if blank]
   Customer Name: [Required - type customer name]
   ```

4. **Click "Create Order"**
5. **Success!** Order appears in the list

### Understanding the Orders List

The orders table shows:

| Column | What It Means |
|--------|--------------|
| **Order #** | Unique order identifier (ORD-12345) |
| **Customer** | Customer name |
| **Status** | Current order status (see below) |
| **Created** | When order was created |
| **Actions** | View details, edit, etc. |

#### Order Status Badges:

- 🔵 **Not Started** (Gray) = Order created, not yet at any station
- 🔵 **In Progress** (Blue) = Order is at a station being worked on
- 🟢 **Completed** (Green) = Order finished, ready for pickup
- 🔴 **Cancelled** (Red) = Order was cancelled

### Order Lifecycle

```
1. Create Order → Status: "Not Started"
   ↓
2. Worker scans at first station → Status: "In Progress"
   ↓
3. Worker completes work, scans out → Still "In Progress"
   ↓
4. Moves through all stations → Still "In Progress"
   ↓
5. Admin marks as Complete → Status: "Completed"
```

### Viewing Order Details

1. Click **"View"** button next to any order
2. See:
   - Customer information
   - Current status
   - Station history (where it's been)
   - Time at each station
   - Materials used
   - Labor costs
   - Total cost

### Managing Order Status

**To Mark Order as Completed:**
1. Order must be checked out of all stations
2. Go to Orders page
3. Click "View" on the order
4. Click "Mark as Completed"

**To Cancel an Order:**
1. Go to Orders page
2. Click "View" on the order
3. Click "Cancel Order"
4. Confirm cancellation
5. **Note:** Cancelled orders cannot be reactivated

### Searching and Filtering

**Find a Specific Order:**
- Use browser search: `Ctrl+F` (Windows) or `Cmd+F` (Mac)
- Type order number or customer name

**View Recent Orders:**
- Orders list shows newest first
- Scroll down for older orders

---

## 📋 Managing Inventory

**Purpose:** Track materials, monitor stock levels, prevent shortages

### What You See

The inventory page shows **all materials** with:

```
Material Name | Type | Quantity | Unit Cost | Status
───────────────────────────────────────────────────
Oak Plywood 4x8 | Wood | 45 sheets | $45.00 | In Stock
Leather - Brown | Leather | 8 yards | $25.00 | ⚠️ Low Stock
Upholstery Fabric | Fabric | 120 yards | $15.00 | In Stock
```

### Understanding Stock Status

#### 🟢 **In Stock** (Green Badge)
- Quantity is above reorder threshold
- No action needed
- Normal inventory level

#### ⚠️ **Low Stock** (Red Badge + Highlighted Row)
- Quantity at or below reorder threshold
- **Action Required:** Reorder this material soon
- Red background makes it easy to spot

### Low Stock Alert

At the top of the page:
```
⚠️ 2 materials are low on stock
```

This count updates automatically.

### How to Use Inventory

**Daily Checks:**
1. Open Inventory page each morning
2. Look for red highlighted rows
3. Note materials with "Low Stock" badge
4. Place orders with suppliers

**Before Creating Orders:**
1. Check if you have enough materials
2. Verify quantities for the specific furniture piece
3. If low, either:
   - Order more materials first
   - Delay the work order
   - Substitute materials if possible

**After Receiving Shipments:**
1. Update quantities in the system
2. (Currently manual - update in database)
3. (Future: Will have "Update Stock" button)

### Inventory Best Practices

✓ **Check inventory daily**
✓ **Reorder when you see "Low Stock" warning**
✓ **Keep safety stock above reorder threshold**
✓ **Update quantities when shipments arrive**
✓ **Plan ahead for large orders**

---

## 🔄 Understanding Workflows

### Normal Order Flow

```
1. ADMIN: Create order in system
   └─→ Order Status: "Not Started"

2. WORKER: Scan order at first station (e.g., Cutting)
   └─→ Order Status: "In Progress"
   └─→ Order appears at Cutting station

3. WORKER: Complete work at Cutting
   └─→ Worker scans order again (checks out)
   └─→ Order disappears from Cutting

4. WORKER: Move physical work to Assembly
   └─→ Worker at Assembly scans order
   └─→ Order appears at Assembly
   └─→ Automatically checked out from Cutting (if forgotten)

5. WORKER: Complete all stations
   └─→ Last station checks out order

6. ADMIN: Mark order as Completed
   └─→ Order Status: "Completed"
   └─→ Ready for customer pickup
```

### How Auto-Transfer Works

**Scenario:** Order is at Cutting, but worker at Assembly scans it

**What Happens:**
1. System detects order is at wrong station
2. **Automatically** checks order out from Cutting
3. Checks order in to Assembly
4. Worker sees: "Order moved from Cutting to Assembly"

**Why This Helps:**
- Workers don't need to check out at old station
- Prevents forgotten checkouts
- Keeps floor view accurate
- Reduces errors

### Station Scanning Logic

| Situation | Action | Result |
|-----------|--------|--------|
| Order not at any station | Scan at Station A | **Check In** to Station A |
| Order at Station A | Scan at Station A again | **Check Out** from Station A |
| Order at Station A | Scan at Station B | **Transfer** (auto checkout from A, check in to B) |

---

## 📈 Reports and Data

### Current Data Available

**Floor View Dashboard:**
- Real-time station status
- Time each order has been at current station
- Number of orders per station

**Orders Page:**
- Complete order history
- Order status tracking
- Customer information

**Inventory Page:**
- Current material quantities
- Stock status
- Unit costs

### Future Features (Planned)

- 📊 Daily production reports
- 💰 Cost analysis per order
- ⏱️ Average time per station
- 📧 Email reports to your inbox
- 💾 Export to Excel/OneDrive
- 📅 Historical trends

---

## 🔧 Troubleshooting

### Common Issues

#### **"Worker says tablet isn't working"**

**Check:**
1. Is tablet connected to WiFi?
2. Is the server computer on?
3. Can you access admin page from another device?
4. Try refreshing the page on tablet
5. Check if URL is correct: `http://[server-ip]:3000/station`

**Fix:**
- Restart tablet if frozen
- Reconnect to WiFi
- Restart server computer if necessary

#### **"Order doesn't show on floor view"**

**Reasons:**
1. Order hasn't been scanned at any station yet
   - Status: "Not Started"
   - Fix: Worker needs to scan it
2. Order was checked out
   - Not at any station currently
   - Fix: Worker needs to scan at next station
3. Page needs refresh
   - Fix: Wait 5 seconds (auto-refresh)

#### **"Worker scanned wrong order"**

**Fix:**
1. Have worker scan the order again immediately
2. This will check it out
3. Then scan at correct location
4. Or manually fix in database (advanced)

#### **"Barcode won't scan"**

**Solutions:**
1. Use "Enter Manually" button on tablet
2. Print new barcode for that order
3. Clean tablet camera
4. Check barcode is not damaged/faded

#### **"Floor view shows wrong time"**

**Reason:** Computer clock is wrong

**Fix:**
1. Set correct time on server computer
2. Restart application
3. Times will be correct for new scans

#### **"Can't create new order"**

**Check:**
1. Customer name is filled in (required)
2. Internet connection is working
3. Database is running (PostgreSQL service)

**Try:**
1. Refresh the page
2. Clear browser cache
3. Check browser console for errors (F12 key)

### Getting Help

**Technical Issues:**
1. Check DEPLOYMENT.md for troubleshooting
2. Restart the application: `npm start`
3. Check database connection in .env file
4. Review error logs in terminal

**Database Issues:**
- PostgreSQL not running: Start it from Services (Windows) or terminal
- Connection refused: Check DATABASE_URL in .env file
- Migration errors: Run `npx prisma migrate deploy`

---

## 💡 Tips and Best Practices

### Daily Routine

**Morning:**
1. ✅ Check Floor View - see overnight orders
2. ✅ Check Inventory - note low stock items
3. ✅ Create today's new orders
4. ✅ Brief workers on priority orders

**During Day:**
1. ✅ Monitor Floor View for bottlenecks
2. ✅ Watch for red cards (orders sitting too long)
3. ✅ Address low stock immediately
4. ✅ Answer worker questions

**End of Day:**
1. ✅ Mark completed orders as "Completed"
2. ✅ Review incomplete orders
3. ✅ Plan tomorrow's work
4. ✅ Order materials if needed

### Order Management Tips

**Creating Orders:**
- ✓ Use clear, unique order numbers
- ✓ Include customer name (for easy identification)
- ✓ Check inventory before creating large orders
- ✓ Create orders in batches for efficiency

**Tracking Orders:**
- ✓ Check floor view multiple times per day
- ✓ Investigate red cards immediately
- ✓ Communicate delays to customers
- ✓ Mark as completed promptly when done

**Handling Problems:**
- ✓ If order is stuck, check with station worker
- ✓ Missing materials? Delay order until received
- ✓ Quality issues? Address immediately
- ✓ Customer changes? Update order notes

### Inventory Management Tips

**Stock Levels:**
- ✓ Set reorder thresholds based on lead time
- ✓ Keep 2-3 weeks of stock for common materials
- ✓ Order before you hit reorder threshold
- ✓ Track seasonal demand patterns

**Cost Control:**
- ✓ Monitor material costs for price increases
- ✓ Compare actual usage vs. planned
- ✓ Investigate discrepancies
- ✓ Negotiate bulk discounts with suppliers

**Organization:**
- ✓ Label physical materials clearly
- ✓ Match labels to database names
- ✓ Count inventory weekly
- ✓ Update system after each shipment

### Worker Communication

**Training:**
- ✓ Show workers the WORKER-GUIDE.md
- ✓ Practice scanning with test orders
- ✓ Explain why scanning is important
- ✓ Answer questions patiently

**Ongoing:**
- ✓ Remind workers to scan at start and end
- ✓ Check floor view matches physical reality
- ✓ Address missed scans quickly
- ✓ Praise accurate scanning

**Troubleshooting:**
- ✓ Be available for questions
- ✓ Fix scanning errors promptly
- ✓ Keep tablets charged and working
- ✓ Have backup plan (manual entry)

### System Maintenance

**Weekly:**
- ✓ Check all tablets are working
- ✓ Update inventory counts
- ✓ Review order history
- ✓ Clean up old completed orders (archive)

**Monthly:**
- ✓ Backup database (see DEPLOYMENT.md)
- ✓ Review material costs
- ✓ Analyze production times
- ✓ Update reorder thresholds if needed

**As Needed:**
- ✓ Print new station barcodes if damaged
- ✓ Add new materials to inventory
- ✓ Add new stations (if expanding)
- ✓ Train new workers

---

## 📞 Support and Resources

### Documentation Files

- **WORKER-GUIDE.md** - Simple instructions for station workers
- **INSTALL.md** - Installation instructions
- **DEPLOYMENT.md** - Advanced server configuration
- **README.md** - Project overview

### Quick Reference

**URLs:**
- Admin Dashboard: `http://localhost:3000/admin`
- Worker Interface: `http://localhost:3000/station`
- API Documentation: See DEPLOYMENT.md

**Key Commands:**
- Start server: `npm start`
- Stop server: `Ctrl+C`
- Rebuild: `npm run build`
- Database: `npx prisma studio` (advanced)

### Need More Help?

**Check Logs:**
- Server terminal shows errors
- Browser console (F12) shows client errors
- Database logs in PostgreSQL logs folder

**System Requirements:**
- Node.js 18+
- PostgreSQL 15+
- Modern web browser
- WiFi network for tablets

---

## 🎯 Quick Decision Guide

### "Should I reorder this material?"
- ✅ YES if: Low Stock warning is showing
- ✅ YES if: Big order coming and quantity is close
- ⏸️ WAIT if: Shipment arriving soon
- ❌ NO if: Well above reorder threshold

### "Is this order taking too long?"
- 🟢 GREEN card: Normal (0-4 hours)
- 🟡 YELLOW card: Investigate (4-8 hours)
- 🔴 RED card: Action needed (8+ hours)

### "Worker forgot to scan"
- **Option 1:** Have them scan now (better)
- **Option 2:** Manually fix in database (if unavailable)
- **Prevention:** Emphasize scanning importance

### "Order needs to be expedited"
- **Tell workers** which order is priority
- **Monitor** on floor view
- **Check in** with workers at each station
- **Ensure materials** are ready

---

## 📝 Notes Section

**Your Custom Notes:**
```
Supplier Contacts:
- Oak Plywood: [Name] [Phone]
- Leather: [Name] [Phone]
- Fabric: [Name] [Phone]

Emergency Contacts:
- IT Support: [Phone]
- Database Admin: [Phone]

Custom Procedures:
- [Add your specific procedures here]
```

---

_This guide covers all current features. System will be updated with more features over time._

_Last Updated: January 2026_
_Version: 1.0_
