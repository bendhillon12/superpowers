# 🎨 UI MOCKUPS - Furniture Tracker
## Visual Guide to All User Interfaces

---

## 📱 WORKER INTERFACE - Station Scanning Page
**URL:** `http://[server-ip]:3000/station`

### Screen 1: Station Selection
```
┌──────────────────────────────────────────────────────┐
│                                                      │
│          Select Your Station                        │
│                                                      │
├──────────────────────────────────────────────────────┤
│                                                      │
│                                                      │
│   ┌────────────────────────────────────────────┐   │
│   │                                            │   │
│   │         🔪 CUTTING                         │   │
│   │                                            │   │
│   └────────────────────────────────────────────┘   │
│                                                      │
│   ┌────────────────────────────────────────────┐   │
│   │                                            │   │
│   │         🔨 ASSEMBLY                        │   │
│   │                                            │   │
│   └────────────────────────────────────────────┘   │
│                                                      │
│   ┌────────────────────────────────────────────┐   │
│   │                                            │   │
│   │         ✨ FINISHING                       │   │
│   │                                            │   │
│   └────────────────────────────────────────────┘   │
│                                                      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

**Features:**
- HUGE buttons (full width, tall)
- Simple icons for each station
- Large text (text-5xl)
- One tap to select

---

### Screen 2: Scanning Interface (Active)
```
┌──────────────────────────────────────────────────────┐
│  🏭 CUTTING                    [Change Station]      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Orders at this station:                            │
│  ┌────────────────────────────────────────────┐    │
│  │  • Order ORD-12345                         │    │
│  │  • Order ORD-12347                         │    │
│  │  • Order ORD-12349                         │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  SCAN ORDER BARCODE                                 │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │                                            │    │
│  │         [CAMERA VIEW]                      │    │
│  │                                            │    │
│  │     Point camera at barcode                │    │
│  │                                            │    │
│  │                                            │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │                                            │    │
│  │         STOP SCANNING                      │    │
│  │                                            │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │         Enter Manually                     │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
└──────────────────────────────────────────────────────┘
```

**Features:**
- Station name prominently displayed
- Current orders list (large text)
- Camera preview box
- HUGE "Stop Scanning" button
- Fallback "Enter Manually" option

---

### Screen 3: Manual Entry Mode
```
┌──────────────────────────────────────────────────────┐
│  🏭 CUTTING                    [Change Station]      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Orders at this station:                            │
│  ┌────────────────────────────────────────────┐    │
│  │  • Order ORD-12345                         │    │
│  │  • Order ORD-12347                         │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │                                            │    │
│  │  Enter barcode manually                    │    │
│  │  ┌──────────────────────────────────┐     │    │
│  │  │ ORD-12346_                       │     │    │
│  │  └──────────────────────────────────┘     │    │
│  │                                            │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │                                            │    │
│  │            SUBMIT                          │    │
│  │                                            │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │        Try Camera Again                    │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
└──────────────────────────────────────────────────────┘
```

**Features:**
- Large input field (text-2xl)
- Auto-focus on input
- HUGE submit button
- Option to go back to camera

---

### Screen 4: Success Message (Green)
```
┌──────────────────────────────────────────────────────┐
│ ✅ Order checked in to CUTTING                      │
└──────────────────────────────────────────────────────┘
│  🏭 CUTTING                    [Change Station]      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Orders at this station:                            │
│  ┌────────────────────────────────────────────┐    │
│  │  • Order ORD-12345                         │    │
│  │  • Order ORD-12346 ← NEW!                  │    │
│  │  • Order ORD-12347                         │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  SCAN ORDER BARCODE                                 │
│  [Camera view ready for next scan...]              │
│                                                      │
└──────────────────────────────────────────────────────┘
```

**Features:**
- Green banner at top (full width)
- Message auto-disappears after 3 seconds
- Order list updates immediately
- Ready for next scan

---

### Screen 5: Error Message (Red)
```
┌──────────────────────────────────────────────────────┐
│ ❌ Order not found                                   │
└──────────────────────────────────────────────────────┘
│  🏭 CUTTING                    [Change Station]      │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Orders at this station:                            │
│  ┌────────────────────────────────────────────┐    │
│  │  • Order ORD-12345                         │    │
│  │  • Order ORD-12347                         │    │
│  └────────────────────────────────────────────┘    │
│                                                      │
│  SCAN ORDER BARCODE                                 │
│  [Camera view - try scanning again...]             │
│                                                      │
└──────────────────────────────────────────────────────┘
```

**Features:**
- Red banner at top
- Clear error message
- Camera still active for retry
- Auto-disappears after 3 seconds

---

## 💼 ADMIN INTERFACE

### Screen 1: Floor View Dashboard
**URL:** `http://localhost:3000/admin`

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ [Floor View] [Orders] [Inventory] [Reports] [Settings]                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Live Floor View                                                            │
│                                                                              │
│  ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐      │
│  │   🔪 CUTTING      │  │  🔨 ASSEMBLY      │  │  ✨ FINISHING     │      │
│  ├───────────────────┤  ├───────────────────┤  ├───────────────────┤      │
│  │                   │  │                   │  │                   │      │
│  │ ┌───────────────┐ │  │ ┌───────────────┐ │  │  No orders       │      │
│  │ │ORD-12345      │ │  │ │ORD-12347      │ │  │                   │      │
│  │ │Smith          │ │  │ │Williams       │ │  │                   │      │
│  │ │2.3h           │ │  │ │5.8h           │ │  │                   │      │
│  │ └───────────────┘ │  │ └───────────────┘ │  │                   │      │
│  │                   │  │                   │  │                   │      │
│  │ ┌───────────────┐ │  │ ┌───────────────┐ │  │                   │      │
│  │ │ORD-12346      │ │  │ │ORD-12348      │ │  │                   │      │
│  │ │Johnson        │ │  │ │Brown          │ │  │                   │      │
│  │ │1.1h           │ │  │ │9.2h           │ │  │                   │      │
│  │ └───────────────┘ │  │ └───────────────┘ │  │                   │      │
│  │  (green bg)       │  │  (yellow bg)      │  │                   │      │
│  │                   │  │  (red bg)         │  │                   │      │
│  └───────────────────┘  └───────────────────┘  └───────────────────┘      │
│                                                                              │
│  Color Legend:                                                              │
│  🟢 Green (0-4h)  🟡 Yellow (4-8h)  🔴 Red (8+ hours)                      │
│                                                                              │
│  Auto-refreshes every 5 seconds                                             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Features:**
- Navigation tabs at top (blue bar)
- Grid layout (3 columns on desktop, 1 on mobile)
- Each station is a card
- Orders color-coded by time
- Clean, professional design
- Auto-refresh indicator

---

### Screen 2: Orders Management
**URL:** `http://localhost:3000/admin/orders`

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ [Floor View] [Orders] [Inventory] [Reports] [Settings]                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Orders                                        [+ New Order]                │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Create New Order                                           [Cancel]│    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │                                                                    │    │
│  │  Order Number                                                      │    │
│  │  ┌──────────────────────────────────────────────────────────┐     │    │
│  │  │ ORD-1705333200000-456                                    │     │    │
│  │  └──────────────────────────────────────────────────────────┘     │    │
│  │  Auto-generated if empty                                          │    │
│  │                                                                    │    │
│  │  Customer Name *                                                   │    │
│  │  ┌──────────────────────────────────────────────────────────┐     │    │
│  │  │ John Smith_                                              │     │    │
│  │  └──────────────────────────────────────────────────────────┘     │    │
│  │                                                                    │    │
│  │  [Create Order]  [Cancel]                                         │    │
│  │                                                                    │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Order #        │ Customer      │ Status        │ Created   │ Actions │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │ ORD-12348      │ Brown         │ Completed     │ Jan 14    │ View    │  │
│  │                │               │ (green badge) │           │         │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │ ORD-12347      │ Williams      │ In Progress   │ Jan 14    │ View    │  │
│  │                │               │ (blue badge)  │           │         │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │ ORD-12346      │ Johnson       │ In Progress   │ Jan 14    │ View    │  │
│  │                │               │ (blue badge)  │           │         │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │ ORD-12345      │ Smith         │ Not Started   │ Jan 14    │ View    │  │
│  │                │               │ (gray badge)  │           │         │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Features:**
- "+ New Order" button (top right, blue)
- Form slides in when clicked
- Table with alternating row colors
- Status badges color-coded
- Hover effect on rows
- Clean, professional table design

---

### Screen 3: Inventory Management
**URL:** `http://localhost:3000/admin/inventory`

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ [Floor View] [Orders] [Inventory] [Reports] [Settings]                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Inventory                                                                  │
│                                                                              │
│  ⚠️ 2 materials are low on stock                                            │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Material           │ Type    │ Quantity      │ Unit Cost │ Status      │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Oak Plywood 4x8    │ Wood    │ 45 sheets     │ $45.00    │ In Stock   │ │
│  │                    │         │               │           │ (green)    │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Leather - Brown    │ Leather │ 8 yards       │ $25.00    │ ⚠️ Low     │ │
│  │ (red background)   │         │ (bold red)    │           │ Stock      │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Upholstery Fabric  │ Fabric  │ 120 yards     │ $15.00    │ In Stock   │ │
│  │                    │         │               │           │ (green)    │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Maple Plywood      │ Wood    │ 5 sheets      │ $50.00    │ ⚠️ Low     │ │
│  │ (red background)   │         │ (bold red)    │           │ Stock      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Total: 4 materials                                                         │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Features:**
- Alert banner for low stock (top, yellow)
- Low stock rows highlighted in red
- Quantity shown in bold red when low
- Warning badge (⚠️ Low Stock)
- Normal stock gets green badge
- Currency formatting for costs
- Total count at bottom

---

## 🎨 DESIGN SYSTEM

### Colors Used:

**Worker Interface:**
- Background: Light gray (`bg-gray-100`)
- Buttons: Large, blue (`bg-blue-600`)
- Success: Green banner (`bg-green-600`)
- Error: Red banner (`bg-red-600`)
- Text: Very large (text-5xl for headings, text-3xl for buttons)

**Admin Interface:**
- Navigation: Dark blue (`bg-blue-900`)
- Active tab: Lighter blue (`bg-blue-700`)
- Cards: White (`bg-white`) with shadow
- Success/Completed: Green (`bg-green-100`)
- In Progress: Blue (`bg-blue-100`)
- Warning/Low Stock: Red (`bg-red-50`, `bg-red-100`)
- Time alerts:
  - Green: `bg-green-100 border-green-400`
  - Yellow: `bg-yellow-100 border-yellow-400`
  - Red: `bg-red-100 border-red-400`

### Typography:

**Worker Interface:**
- Station names: text-5xl (very large)
- Buttons: text-3xl (large)
- Order numbers: text-2xl (medium-large)

**Admin Interface:**
- Page titles: text-3xl font-bold
- Section headings: text-2xl font-semibold
- Table text: text-base (normal)
- Badges: text-sm (small)

### Spacing:

**Worker Interface:**
- Large padding (p-6, p-8)
- Big gaps between elements (gap-6, space-y-6)
- Full-width buttons for easy tapping

**Admin Interface:**
- Standard padding (p-4, p-6)
- Clean spacing (gap-4, space-y-4)
- Compact for information density

---

## 📱 RESPONSIVE DESIGN

### Mobile/Tablet (Worker Interface):
- Full screen buttons
- Stacked vertically
- No horizontal scrolling
- Large touch targets (minimum 44x44px)

### Desktop (Admin Interface):
- Floor View: 3-column grid
- Orders: Full-width table
- Inventory: Full-width table
- Navigation: Horizontal tabs

### Tablet (Admin Interface):
- Floor View: 2-column grid
- Tables still readable
- Navigation stays horizontal

---

## 🎯 KEY UI PRINCIPLES

### Worker Interface:
1. **Simplicity First** - Minimal cognitive load
2. **Large Everything** - Easy to see and tap
3. **Clear Feedback** - Green/red messages
4. **Forgiving** - Easy to recover from mistakes
5. **Mobile-First** - Designed for tablets

### Admin Interface:
1. **Information Density** - See lots of data at once
2. **Professional Look** - Clean, organized tables
3. **Color Coding** - Quick visual scanning
4. **Responsive** - Works on any screen size
5. **Auto-Refresh** - Always up-to-date

---

## 📸 Actual Screenshots

To see the actual UI in action, you can:

1. **Run locally:**
   ```bash
   cd furniture-tracker
   npm start
   ```
   Then visit:
   - Worker: http://localhost:3000/station
   - Admin: http://localhost:3000/admin

2. **Preview in browser dev tools:**
   - Press F12
   - Click mobile device icon
   - Resize to see responsive behavior

The actual UI uses:
- **Tailwind CSS** for styling
- **Next.js** for rendering
- **React** for interactivity
- Modern browser features (camera API, etc.)

All designs follow material design principles with custom furniture-industry theming!
