# ✅ SETUP CHECKLIST
## First-Time Deployment Guide - Print This and Check Off Each Step!

---

## 📋 PRE-INSTALLATION (Before Setup Day)

### Hardware Preparation
- [ ] Server computer selected (Windows/Mac/Linux)
- [ ] Server computer has stable power supply
- [ ] WiFi router installed and tested
- [ ] Tablets purchased (1 per station minimum)
- [ ] Tablets charged fully
- [ ] All devices connected to same WiFi network

### Software Downloads
- [ ] Downloaded Node.js 18+ from https://nodejs.org/
- [ ] Downloaded PostgreSQL 15+ from https://www.postgresql.org/
- [ ] Downloaded furniture-tracker application backup zip
- [ ] Extracted furniture-tracker to a permanent location

### Information Gathering
- [ ] Decided on database password (write it down!)
- [ ] Listed all station names (Cutting, Assembly, etc.)
- [ ] Listed all material types to track
- [ ] Identified admin user(s)
- [ ] Identified worker users

---

## 💻 INSTALLATION DAY

### Part 1: Install Prerequisites (30-45 minutes)

**Install Node.js:**
- [ ] Run Node.js installer
- [ ] Choose "LTS" version
- [ ] Check "Add to PATH" option
- [ ] Complete installation
- [ ] Open terminal and verify: `node -v` shows version

**Install PostgreSQL:**
- [ ] Run PostgreSQL installer
- [ ] Remember the password you set! ⚠️
- [ ] Note: Default user is usually "postgres"
- [ ] Complete installation
- [ ] Verify PostgreSQL is running

**Verify Installation:**
- [ ] Terminal command `node -v` works
- [ ] Terminal command `npm -v` works
- [ ] Terminal command `psql --version` works

### Part 2: Run Automated Installer (10-15 minutes)

**Windows:**
- [ ] Open PowerShell as Administrator
- [ ] Navigate to furniture-tracker folder
- [ ] Run: `.\install.ps1`

**Mac/Linux:**
- [ ] Open Terminal
- [ ] Navigate to furniture-tracker folder
- [ ] Run: `chmod +x install.sh`
- [ ] Run: `./install.sh`

**Follow Prompts:**
- [ ] Database host: Press Enter (use localhost)
- [ ] Database port: Press Enter (use 5432)
- [ ] Database name: Press Enter (use furniture_tracker)
- [ ] Database username: Press Enter (use postgres)
- [ ] Database password: Enter YOUR password ⚠️
- [ ] Seed sample data: Type `y` and Enter
- [ ] Install as service (Windows): Type `y` if you want auto-start
- [ ] Start now: Type `y` to test

**Verify Installation:**
- [ ] Installation completed without errors
- [ ] Server started successfully
- [ ] Browser opens to admin dashboard
- [ ] Can see 3 sample stations (Cutting, Assembly, Finishing)

---

## 🔧 POST-INSTALLATION CONFIGURATION

### Part 3: Server Computer Setup (10 minutes)

**Find Server IP Address:**
- [ ] Installer shows IP address (e.g., 192.168.1.100)
- [ ] Write it down: `___________________`
- [ ] Test from another device: `http://[IP]:3000/admin`

**Windows Service (if installed):**
- [ ] Open Services (Run: `services.msc`)
- [ ] Find "Furniture Tracker" service
- [ ] Verify status is "Running"
- [ ] Verify startup type is "Automatic"

**Firewall Configuration:**
- [ ] Windows: Run firewall rule creation from INSTALL.md
- [ ] Mac: Allow Node.js in Security & Privacy
- [ ] Linux: Run `sudo ufw allow 3000/tcp`
- [ ] Test access from tablet on same WiFi

**Network Configuration:**
- [ ] All tablets on same WiFi as server
- [ ] WiFi name: `___________________`
- [ ] WiFi password (write somewhere safe)
- [ ] Server IP accessible from all tablets

### Part 4: Data Setup (15-20 minutes)

**Customize Stations (if needed):**
- [ ] Open admin dashboard
- [ ] Go to Floor View
- [ ] Verify 3 sample stations appear
- [ ] Modify station names if needed
- [ ] Add more stations if needed
- [ ] Delete sample stations if starting fresh

**Add Materials:**
- [ ] Click "Inventory" in admin dashboard
- [ ] Review 3 sample materials
- [ ] Add your actual materials:
  - [ ] Material 1: `___________________`
  - [ ] Material 2: `___________________`
  - [ ] Material 3: `___________________`
  - [ ] (Add more as needed)
- [ ] Set correct unit costs
- [ ] Set reorder thresholds

**Test Order Creation:**
- [ ] Click "Orders" in admin dashboard
- [ ] Click "+ New Order"
- [ ] Create test order:
  - Customer: "Test Customer"
  - Order Number: "TEST-001"
- [ ] Verify order appears in list
- [ ] Verify order status is "Not Started"

### Part 5: Barcode Setup (30 minutes)

**Generate Station Barcodes:**
- [ ] Option A: Use online barcode generator
  - Go to: https://barcode.tec-it.com/
  - Format: Code 128
  - Content: Station ID from database
- [ ] Option B: Use barcode software
- [ ] Generate 1 barcode per station
- [ ] Print barcodes (large enough to scan easily)
- [ ] Laminate barcodes (for durability)

**Post Barcodes:**
- [ ] Station 1 barcode posted at station
- [ ] Station 2 barcode posted at station
- [ ] Station 3 barcode posted at station
- [ ] (Additional stations as needed)
- [ ] Barcodes at eye level, well-lit area
- [ ] Protected from damage

**Test Barcodes:**
- [ ] Can scan each station barcode with tablet
- [ ] Scanner recognizes barcode
- [ ] Correct station name appears

### Part 6: Tablet Configuration (15 minutes per tablet)

**For Each Tablet:**

Tablet 1 (Station: `_________________`):
- [ ] Charged to 100%
- [ ] Connected to WiFi
- [ ] Brightness set to high
- [ ] Auto-sleep disabled (or set to 30 mins)
- [ ] Browser opened
- [ ] Bookmarked: `http://[server-ip]:3000/station`
- [ ] Set bookmark as homepage
- [ ] Tested scanning with station barcode
- [ ] Placed at station with charger

Tablet 2 (Station: `_________________`):
- [ ] (Repeat checklist above)

Tablet 3 (Station: `_________________`):
- [ ] (Repeat checklist above)

---

## 👥 USER TRAINING

### Part 7: Admin Training (30-45 minutes)

**Show Admin User(s):**
- [ ] How to access: `http://localhost:3000/admin` or `http://[IP]:3000/admin`
- [ ] Bookmark the URL
- [ ] Floor View dashboard overview
  - What each color means
  - How often it refreshes
  - What to look for
- [ ] Creating new orders
  - Required fields
  - Optional fields
  - Status meanings
- [ ] Checking inventory
  - Low stock warnings
  - When to reorder
- [ ] Reading order history
- [ ] Basic troubleshooting

**Give Admin User(s):**
- [ ] Copy of ADMIN-GUIDE.md (printed)
- [ ] Copy of TROUBLESHOOTING-FLOWCHART.md (printed)
- [ ] Server computer login credentials
- [ ] Database password (stored securely)
- [ ] WiFi password
- [ ] Contact numbers for support

**Admin Practice:**
- [ ] Create a real order
- [ ] Check floor view
- [ ] Check inventory
- [ ] Find an order by number
- [ ] Mark test order as completed

### Part 8: Worker Training (15 minutes per worker)

**For Each Worker:**

Worker Name: `_________________` Station: `_________________`

**Show Worker:**
- [ ] Where their tablet is located
- [ ] How to turn it on / wake it up
- [ ] How to select station
- [ ] How to start scanning
- [ ] How to scan a barcode
- [ ] What green message means
- [ ] What red message means
- [ ] Manual entry option (backup)
- [ ] Who to call if problems

**Give Worker:**
- [ ] Copy of WORKER-GUIDE.md (printed, laminated)
- [ ] Copy of QUICK-REFERENCE-CARD.md (posted at station)
- [ ] Supervisor contact number
- [ ] WiFi password (if they ask)

**Worker Practice:**
- [ ] Select correct station
- [ ] Start scanning
- [ ] Scan test barcode
- [ ] See order appear in list
- [ ] Scan again to check out
- [ ] See order disappear
- [ ] Try manual entry
- [ ] Ask questions

**Repeat for All Workers:**
- [ ] Worker 1 trained
- [ ] Worker 2 trained
- [ ] Worker 3 trained
- [ ] (Additional workers as needed)

---

## 🧪 TESTING PHASE (Day 1-3)

### Day 1: Parallel Running
- [ ] Keep old system running
- [ ] Start using new system for new orders
- [ ] Admin monitors floor view hourly
- [ ] Address issues immediately
- [ ] Workers get comfortable with scanning

### Day 2: Full Operation
- [ ] All new orders use new system
- [ ] Old orders finish on old system
- [ ] Admin checks accuracy vs. physical floor
- [ ] Note any discrepancies
- [ ] Adjust worker training if needed

### Day 3: Evaluation
- [ ] Review any problems that occurred
- [ ] Make necessary adjustments
- [ ] Additional training if needed
- [ ] Verify inventory is accurate
- [ ] Plan for full transition

---

## ✅ GO-LIVE CHECKLIST (Day 4)

### Pre-Launch Final Checks
- [ ] Server running and stable
- [ ] All tablets working
- [ ] All barcodes in place
- [ ] All workers trained
- [ ] Admin confident
- [ ] Backup of database created
- [ ] Old system ready to retire

### Launch Day
- [ ] Start with normal operations
- [ ] Admin on-site all day
- [ ] Quick response to any issues
- [ ] Positive reinforcement for workers
- [ ] Document any problems
- [ ] Celebrate success! 🎉

---

## 📅 ONGOING MAINTENANCE

### Daily (5 minutes)
- [ ] Check Floor View for accuracy
- [ ] Check Inventory for low stock
- [ ] Verify tablets are charged

### Weekly (15 minutes)
- [ ] Clean tablet cameras
- [ ] Review order history
- [ ] Update inventory counts
- [ ] Address any issues

### Monthly (30 minutes)
- [ ] Backup database
- [ ] Review material costs
- [ ] Check barcode condition
- [ ] Update software if available
- [ ] Review worker training

---

## 📞 IMPORTANT INFORMATION TO KEEP

**Write This Information Somewhere Safe:**

```
Server Computer:
- Location: ____________________
- Username: ____________________
- Password: ____________________

Database:
- Username: ____________________
- Password: ____________________

Network:
- WiFi Name: ____________________
- WiFi Password: ____________________
- Server IP: ____________________

Access URLs:
- Admin: http://____________________:3000/admin
- Worker: http://____________________:3000/station

Contacts:
- IT Support: ____________________
- Supervisor: ____________________
- Database Admin: ____________________

Backup Schedule:
- Daily: ____________________
- Weekly: ____________________
- Location: ____________________
```

---

## 🎯 SUCCESS CRITERIA

You'll know the system is working well when:

✅ Workers scan consistently without reminders
✅ Floor View matches physical reality
✅ Low stock warnings help prevent shortages
✅ Admin can track any order instantly
✅ No scanning errors for full day
✅ Orders move smoothly through stations
✅ Time tracking shows realistic values
✅ System saves time vs. old method

---

## 🎉 CONGRATULATIONS!

If you've checked off all items above, your Furniture Manufacturing Tracker is now fully operational!

**Next Steps:**
- Keep using the system daily
- Track improvements in efficiency
- Consider adding features (reports, etc.)
- Train new workers as they join
- Maintain the system regularly

**Enjoy better visibility into your manufacturing process!**

---

_Setup completed by: ____________________  Date: _____________________
_System administrator: ____________________  Phone: _____________________
