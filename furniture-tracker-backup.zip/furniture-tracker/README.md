# Furniture Manufacturing Tracker

Progressive Web App for tracking furniture manufacturing work-in-progress with barcode scanning.

## Features

- Barcode scanning at workstations (camera or handheld scanner)
- Real-time floor view dashboard
- Order and inventory management
- Time and cost tracking per station
- Email and OneDrive report integration

## Tech Stack

- Next.js 16
- PostgreSQL
- Prisma ORM
- Tailwind CSS
- QuaggaJS (barcode scanning)

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Set up database:
```bash
cp .env.example .env
# Edit .env with your database credentials
npx prisma migrate dev
npx prisma generate
```

3. Run development server:
```bash
npm run dev
```

4. Access:
- Worker interface: http://localhost:3000/station
- Admin dashboard: http://localhost:3000/admin

## Documentation

See [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment instructions.
