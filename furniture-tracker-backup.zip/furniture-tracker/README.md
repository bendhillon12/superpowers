# Furniture Manufacturing Tracker

Progressive Web App for tracking furniture manufacturing work-in-progress with barcode scanning.

## ⚡ Automated Installation (Recommended)

**The easiest way to install:**

### Windows:
```powershell
# Run PowerShell as Administrator
.\install.ps1
```

### Mac/Linux:
```bash
chmod +x install.sh
./install.sh
```

The installation wizard will:
- Check prerequisites (Node.js, PostgreSQL)
- Install all dependencies
- Configure the database
- Set up environment variables
- Run migrations and seed sample data
- Build the application
- Display network access instructions

**For detailed instructions, see [INSTALL.md](./INSTALL.md)**

## Features

- Barcode scanning at workstations (camera or handheld scanner)
- Real-time floor view dashboard
- Order and inventory management
- Time and cost tracking per station
- Email and OneDrive report integration
- Worker-friendly interface (large buttons, simple workflow)
- Admin dashboard with live updates

## Tech Stack

- Next.js 16
- PostgreSQL
- Prisma ORM
- Tailwind CSS
- QuaggaJS (barcode scanning)
- TypeScript

## Manual Installation

If you prefer to install manually:

1. Install dependencies:
```bash
npm install
```

2. Set up database:
```bash
cp .env.example .env
# Edit .env with your database credentials
npx prisma migrate deploy
npx prisma generate
```

3. Seed initial data:
```bash
node scripts/seed-stations.js
```

4. Build and start:
```bash
npm run build
npm start
```

5. Access:
- Worker interface: http://localhost:3000/station
- Admin dashboard: http://localhost:3000/admin

## Documentation

- **[INSTALL.md](./INSTALL.md)** - Quick installation guide (START HERE!)
- **[DEPLOYMENT.md](./DEPLOYMENT.md)** - Production deployment and advanced configuration
- **[Implementation Plan](./docs/plans/2026-01-15-furniture-tracker-implementation.md)** - Technical implementation details
